from typing import Dict, Any, List, Optional

class AccessibilityDetector:
    """
    Approach B Component: Accessibility Tree & WCAG Rule Audit Engine.
    Inspects accessibility snapshots, roles, accessible names, focusability, and touch target bounds.
    """

    def compare_accessibility_tree(
        self,
        reference_tree: Dict[str, Any],
        actual_tree: Dict[str, Any],
        dom_nodes: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyzes actual accessibility tree and DOM metadata against accessibility standards.
        Detects missing accessible names, role mismatches, non-focusable controls, and small touch targets.
        """
        accessibility_defects: List[Dict[str, Any]] = []

        # 1. Audit Interactive DOM Elements for WCAG & A11y Standards
        for node in dom_nodes:
            tag = node.get("tag", "")
            role = node.get("role", "")
            aria_label = node.get("ariaLabel", "")
            text = node.get("text", "")
            bounds = node.get("bounds", {"width": 0, "height": 0})

            # Check 1: Missing Accessible Name on Interactive Controls
            if tag in ["button", "input", "select", "a"] or role in ["button", "link", "textbox"]:
                has_name = bool(aria_label or text)
                if not has_name:
                    accessibility_defects.append({
                        "defect_type": "ACCESSIBLE_NAME_MISSING",
                        "severity": "HIGH",
                        "element_id": node.get("id", tag),
                        "explanation": f"Interactive control <{tag} id='{node.get('id')}'> has no accessible name or aria-label."
                    })

            # Check 2: Role Mismatch (e.g. button rendered with role='paragraph')
            if tag == "button" and role not in ["button", "link"]:
                accessibility_defects.append({
                    "defect_type": "ROLE_MISMATCH",
                    "severity": "HIGH",
                    "element_id": node.get("id", tag),
                    "explanation": f"Button element <{tag} id='{node.get('id')}'> has non-standard role='{role}'."
                })

            # Check 3: Touch Target Size (WCAG 2.1 AA 2.5.5 - minimum 44x44px for buttons)
            if tag == "button" or role == "button":
                if bounds["width"] < 44 or bounds["height"] < 44:
                    accessibility_defects.append({
                        "defect_type": "CONTROL_TOO_SMALL",
                        "severity": "MEDIUM",
                        "element_id": node.get("id", tag),
                        "explanation": f"Button touch target is too small ({bounds['width']}x{bounds['height']}px). WCAG minimum is 44x44px."
                    })

            # Check 4: Keyboard Focusability
            if (tag in ["button", "input"] or role == "button") and not node.get("focusable", False):
                accessibility_defects.append({
                    "defect_type": "KEYBOARD_ACCESSIBILITY_FAILURE",
                    "severity": "CRITICAL",
                    "element_id": node.get("id", tag),
                    "explanation": f"Interactive element <{tag} id='{node.get('id')}'> is not focusable via keyboard navigation."
                })

        # Calculate Accessibility Score (1.0 = fully accessible, 0.0 = total a11y breakdown)
        accessibility_score = max(0.0, 1.0 - (len(accessibility_defects) * 0.20))

        return {
            "accessibility_score": round(accessibility_score, 4),
            "accessibility_defects": accessibility_defects,
            "total_nodes_audited": len(dom_nodes)
        }
