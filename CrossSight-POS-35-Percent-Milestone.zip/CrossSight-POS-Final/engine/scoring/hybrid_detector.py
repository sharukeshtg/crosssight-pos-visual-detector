import json
from typing import Dict, Any, List, Optional
from engine.visual.pixel_detector import PixelVisualDetector
from engine.structural.structural_detector import StructuralDetector
from engine.accessibility.accessibility_detector import AccessibilityDetector
from engine.localization.localization_detector import LocalizationDetector

class HybridDetector:
    """
    Approach B: Integrated Hybrid Detector.
    Combines Visual, Geometry/Structural, Accessibility, and Localization analysis into an explainable regression score.
    """
    DETECTOR_VERSION = "detector-v2-hybrid"
    THRESHOLD_VERSION = "threshold-v1.0"

    def __init__(self, visual_weight: float = 0.25, geometry_weight: float = 0.25, a11y_weight: float = 0.25, loc_weight: float = 0.25):
        self.visual_weight = visual_weight
        self.geometry_weight = geometry_weight
        self.a11y_weight = a11y_weight
        self.loc_weight = loc_weight

        self.pixel_detector = PixelVisualDetector()
        self.structural_detector = StructuralDetector()
        self.accessibility_detector = AccessibilityDetector()
        self.localization_detector = LocalizationDetector()

    def run_hybrid_detection(
        self,
        reference_snapshot: Dict[str, Any],
        actual_snapshot: Dict[str, Any],
        output_diff_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Runs comprehensive Approach B hybrid detection pipeline.
        """
        ref_img = reference_snapshot["screenshot_path"]
        act_img = actual_snapshot["screenshot_path"]

        ref_meta = self._load_json(reference_snapshot["metadata_path"]) or []
        act_meta = self._load_json(actual_snapshot["metadata_path"]) or []
        ref_a11y = self._load_json(reference_snapshot["accessibility_path"]) or {}
        act_a11y = self._load_json(actual_snapshot["accessibility_path"]) or {}

        lang = actual_snapshot.get("language", "en")
        device_width = actual_snapshot.get("device", {}).get("width", 1920)

        # 1. Visual Component
        visual_res = self.pixel_detector.compare_screenshots(ref_img, act_img, output_diff_path)
        visual_score = visual_res["visual_score"]

        # 2. Structural & Geometry Component
        struct_res = self.structural_detector.compare_geometry(ref_meta, act_meta)
        geometry_score = struct_res["geometry_score"]

        # 3. Accessibility Component
        a11y_res = self.accessibility_detector.compare_accessibility_tree(ref_a11y, act_a11y, act_meta)
        accessibility_score = a11y_res["accessibility_score"]

        # 4. Localization Component
        loc_res = self.localization_detector.analyze_localization(lang, act_meta, device_width)
        localization_score = loc_res["localization_score"]

        # 5. Weighted Aggregate Regression Score (1.0 = perfect match, 0.0 = severe regression)
        overall_score = (
            (visual_score * self.visual_weight) +
            (geometry_score * self.geometry_weight) +
            (accessibility_score * self.a11y_weight) +
            (localization_score * self.loc_weight)
        )
        overall_score = round(overall_score, 4)

        # Collect all detected defects
        all_defects = (
            struct_res["structural_defects"] +
            a11y_res["accessibility_defects"] +
            loc_res["localization_defects"]
        )

        # 6. Defect Classification & Severity
        if not all_defects and overall_score >= 0.95:
            classification = "ACCEPTABLE_VARIATION" if overall_score < 1.0 else "PASS"
            severity = "NONE"
            primary_defect_type = "NONE"
            explanation = "No visual or structural regressions detected across configuration."
        else:
            classification = "TRUE_DEFECT"
            
            # Determine highest severity
            severities = [d["severity"] for d in all_defects]
            if "CRITICAL" in severities:
                severity = "CRITICAL"
            elif "HIGH" in severities:
                severity = "HIGH"
            elif "MEDIUM" in severities:
                severity = "MEDIUM"
            else:
                severity = "LOW"

            primary_defect_type = all_defects[0]["defect_type"] if all_defects else "VISUAL_MISMATCH"

            # Build explainability summary
            defect_explanations = [d["explanation"] for d in all_defects]
            explanation = (
                f"Regression Detected [{severity}]: {primary_defect_type}. "
                f"Overall Score: {overall_score} (Visual: {visual_score}, Geometry: {geometry_score}, A11y: {accessibility_score}, L10n: {localization_score}). "
                f"Details: {' | '.join(defect_explanations[:3])}"
            )

        return {
            "detector_mode": "HYBRID",
            "detector_version": self.DETECTOR_VERSION,
            "threshold_version": self.THRESHOLD_VERSION,
            "overall_regression_score": overall_score,
            "visual_score": visual_score,
            "ssim_score": visual_res["ssim_score"],
            "geometry_score": geometry_score,
            "accessibility_score": accessibility_score,
            "localization_score": localization_score,
            "difference_percentage": visual_res["difference_percentage"],
            "classification": classification,
            "severity": severity,
            "primary_defect_type": primary_defect_type,
            "explanation": explanation,
            "detected_defects": all_defects,
            "diff_image_path": visual_res.get("diff_image_path")
        }

    def _load_json(self, path: Optional[str]) -> Any:
        if not path or not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
