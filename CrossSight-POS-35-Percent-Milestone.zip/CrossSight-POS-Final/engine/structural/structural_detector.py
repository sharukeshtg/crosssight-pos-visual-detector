import math
from typing import Dict, Any, List, Optional

class StructuralDetector:
    """
    Approach B Component: DOM Structural & Bounding-Box Geometry Analyzer.
    Analyzes DOM element positioning, layout relationships, bounding box overlaps, clipping, and text wrapping.
    """

    def compare_geometry(
        self,
        reference_nodes: List[Dict[str, Any]],
        actual_nodes: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Compares reference DOM nodes against actual DOM nodes.
        Detects missing elements, position shifts, size changes, bounding box collisions (overlaps), and text clipping.
        """
        defects_detected: List[Dict[str, Any]] = []
        
        ref_map = {n.get("id") or f"{n['tag']}_{n['text'][:20]}": n for n in reference_nodes if n.get("visibility")}
        act_map = {n.get("id") or f"{n['tag']}_{n['text'][:20]}": n for n in actual_nodes if n.get("visibility")}

        # 1. Missing or Unexpected Elements
        for key, ref_el in ref_map.items():
            if key not in act_map:
                defects_detected.append({
                    "defect_type": "MISSING_ELEMENT",
                    "severity": "CRITICAL" if "btn" in key or "total" in key else "HIGH",
                    "element_id": ref_el.get("id", ""),
                    "element_tag": ref_el.get("tag", ""),
                    "explanation": f"Element '{key}' was present in reference but missing in actual view."
                })

        # 2. Position Shifts & Size Changes
        for key, act_el in act_map.items():
            if key in ref_map:
                ref_el = ref_map[key]
                rb = ref_el["bounds"]
                ab = act_el["bounds"]

                dx = abs(rb["x"] - ab["x"])
                dy = abs(rb["y"] - ab["y"])
                dw = abs(rb["width"] - ab["width"])
                dh = abs(rb["height"] - ab["height"])

                # Position Shift (> 35px)
                if dx > 35 or dy > 35:
                    defects_detected.append({
                        "defect_type": "LAYOUT_SHIFT",
                        "severity": "HIGH",
                        "element_id": act_el.get("id", ""),
                        "explanation": f"Element '{key}' moved by dx={dx}px, dy={dy}px from reference position ({rb['x']},{rb['y']}) to ({ab['x']},{ab['y']})."
                    })

                # Size Change (> 40px)
                if dw > 40 or dh > 40:
                    defects_detected.append({
                        "defect_type": "WRAPPING_ERROR" if dw > 50 else "LAYOUT_SHIFT",
                        "severity": "MEDIUM",
                        "element_id": act_el.get("id", ""),
                        "explanation": f"Element '{key}' changed dimensions from {rb['width']}x{rb['height']} to {ab['width']}x{ab['height']}."
                    })

        # 3. Bounding Box Overlap / Collision Detection
        act_elements = list(act_map.values())
        for i in range(len(act_elements)):
            for j in range(i + 1, len(act_elements)):
                el1 = act_elements[i]
                el2 = act_elements[j]
                
                # Ignore nested containment ONLY if one is a recognized container element
                if self._is_container_containment(el1, el2):
                    continue

                if self._check_overlap(el1["bounds"], el2["bounds"]):
                    # Overlap detected!
                    defects_detected.append({
                        "defect_type": "OVERLAP",
                        "severity": "CRITICAL" if "btn" in el1.get("id", "") or "btn" in el2.get("id", "") else "HIGH",
                        "element_id": f"{el1.get('id', '')} & {el2.get('id', '')}",
                        "explanation": f"Element '{el1.get('id') or el1['tag']}' visually overlaps '{el2.get('id') or el2['tag']}' causing layout collision."
                    })

        # Geometry score calculation (1.0 = perfect match, 0.0 = total breakage)
        geometry_score = max(0.0, 1.0 - (len(defects_detected) * 0.15))

        return {
            "geometry_score": round(geometry_score, 4),
            "structural_defects": defects_detected,
            "ref_element_count": len(ref_map),
            "act_element_count": len(act_map)
        }

    def _check_overlap(self, b1: Dict[str, int], b2: Dict[str, int]) -> bool:
        """Returns True if bounding box b1 intersects b2 with significant area."""
        x_left = max(b1["x"], b2["x"])
        y_top = max(b1["y"], b2["y"])
        x_right = min(b1["x"] + b1["width"], b2["x"] + b2["width"])
        y_bottom = min(b1["y"] + b1["height"], b2["y"] + b2["height"])

        if x_right > x_left and y_bottom > y_top:
            intersection_area = (x_right - x_left) * (y_bottom - y_top)
            min_area = min(b1["width"] * b1["height"], b2["width"] * b2["height"])
            # Require at least 20% overlap of the smaller box
            return (intersection_area / max(1, min_area)) > 0.20
        return False

    def _is_container_containment(self, el1: Dict[str, Any], el2: Dict[str, Any]) -> bool:
        """Returns True if containment is legitimate parent-child container hierarchy."""
        container_tags = {"card", "main", "nav", "header", "table", "form", "section", "div"}
        tag1 = el1.get("tag", "").lower()
        tag2 = el2.get("tag", "").lower()

        # If neither is a container element (e.g. button and span/text), overlap is invalid!
        if tag1 not in container_tags and tag2 not in container_tags:
            return False

        b1, b2 = el1["bounds"], el2["bounds"]
        b1_in_b2 = (b1["x"] >= b2["x"] and b1["y"] >= b2["y"] and 
                    b1["x"] + b1["width"] <= b2["x"] + b2["width"] and 
                    b1["y"] + b1["height"] <= b2["y"] + b2["height"])
        b2_in_b1 = (b2["x"] >= b1["x"] and b2["y"] >= b1["y"] and 
                    b2["x"] + b2["width"] <= b1["x"] + b1["width"] and 
                    b2["y"] + b2["height"] <= b1["y"] + b1["height"])

        return (b1_in_b2 and tag2 in container_tags) or (b2_in_b1 and tag1 in container_tags)
