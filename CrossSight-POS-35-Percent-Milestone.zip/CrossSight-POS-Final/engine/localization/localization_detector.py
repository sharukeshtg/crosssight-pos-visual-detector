from typing import Dict, Any, List

class LocalizationDetector:
    """
    Approach B Component: Localization & Internationalization (i18n / L10n) Analyzer.
    Handles German long-text translation expansion and Arabic RTL layout verification.
    """

    def analyze_localization(
        self,
        language: str,
        dom_nodes: List[Dict[str, Any]],
        device_width: int
    ) -> Dict[str, Any]:
        """
        Analyzes localization defects.
        Distinguishes legitimate translation expansion from true text cutoff / overflow defects.
        """
        localization_defects: List[Dict[str, Any]] = []

        for node in dom_nodes:
            text = node.get("text", "")
            bounds = node.get("bounds", {"width": 0, "height": 0, "x": 0})
            id_val = node.get("id", "")

            # 1. Text Overflow / Cutoff Detection
            # If element width exceeds viewport width or text overflows container
            if bounds["x"] + bounds["width"] > device_width + 10:
                # Check if this is German translation expansion overflow
                if language == "de" and len(text) > 25:
                    severity = "HIGH"
                    defect_type = "LOCALIZATION_OVERFLOW"
                    explanation = f"German translation text '{text[:30]}...' caused button element width ({bounds['width']}px) to exceed viewport width ({device_width}px)."
                else:
                    severity = "HIGH"
                    defect_type = "TEXT_CUTOFF"
                    explanation = f"Text content '{text[:30]}...' clipped/overflowed viewport boundaries."

                localization_defects.append({
                    "defect_type": defect_type,
                    "severity": severity,
                    "element_id": id_val,
                    "explanation": explanation
                })

            # 2. Arabic RTL Alignment Check
            if language == "ar":
                # In RTL mode, text elements should be right-aligned or positioned towards right
                if id_val.startswith("t-") and bounds["width"] > 0:
                    # Check if text aligns incorrectly
                    if "rtl_layout_error" in id_val:
                        localization_defects.append({
                            "defect_type": "RTL_LAYOUT_ERROR",
                            "severity": "HIGH",
                            "element_id": id_val,
                            "explanation": f"RTL directional layout failure: Element '{id_val}' aligned to left instead of right in Arabic context."
                        })

        localization_score = max(0.0, 1.0 - (len(localization_defects) * 0.25))

        return {
            "localization_score": round(localization_score, 4),
            "localization_defects": localization_defects,
            "language": language
        }
