import os
import json
import datetime
import asyncio
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from backend.app.core.config import settings
from backend.app.models.models import (
    User, Project, Screen, Device, Language, AccessibilityProfile,
    Baseline, BaselineVersion, TestRun, ActualSnapshot, Defect, Evidence,
    Review, AuditLog, Experiment, GroundTruthCase, RollbackEvent
)
from backend.app.schemas.schemas import ProjectCreate, TestRunCreate, DefectReviewRequest, RollbackRequest
from engine.playwright.playwright_runner import PlaywrightRunner
from engine.visual.pixel_detector import PixelVisualDetector
from engine.scoring.hybrid_detector import HybridDetector
from engine.evidence.evidence_generator import EvidenceGenerator

class PlatformService:
    def __init__(self, db: Session, artifact_dir: str = "./artifacts"):
        self.db = db
        self.artifact_dir = artifact_dir
        self.runner = PlaywrightRunner(artifact_base_dir=artifact_dir, pos_url=settings.POS_APP_URL)
        self.pixel_detector = PixelVisualDetector()
        self.hybrid_detector = HybridDetector()
        self.evidence_generator = EvidenceGenerator(artifact_base_dir=artifact_dir)

    # Seed Default Reference Master Data
    def seed_master_data(self):
        # 1. Default Devices
        devices = [
            {"name": "Desktop 1080p", "device_key": "desktop_1920x1080", "width": 1920, "height": 1080, "dpr": 1.0},
            {"name": "Desktop Small", "device_key": "desktop_1366x768", "width": 1366, "height": 768, "dpr": 1.0},
            {"name": "Tablet Landscape", "device_key": "tablet_1024x768", "width": 1024, "height": 768, "dpr": 2.0},
            {"name": "Tablet Portrait", "device_key": "tablet_portrait_768x1024", "width": 768, "height": 1024, "dpr": 2.0},
            {"name": "Mobile Viewport", "device_key": "mobile_390x844", "width": 390, "height": 844, "dpr": 3.0},
            {"name": "POS Kiosk", "device_key": "pos_kiosk_1280x720", "width": 1280, "height": 720, "dpr": 1.5}
        ]
        for d in devices:
            if not self.db.query(Device).filter(Device.device_key == d["device_key"]).first():
                self.db.add(Device(**d))

        # 2. Languages
        languages = [
            {"code": "en", "name": "English", "is_rtl": False},
            {"code": "de", "name": "Deutsch (German)", "is_rtl": False},
            {"code": "ar", "name": "العربية (Arabic)", "is_rtl": True},
            {"code": "ta", "name": "தமிழ் (Tamil)", "is_rtl": False},
            {"code": "hi", "name": "हिन्दी (Hindi)", "is_rtl": False}
        ]
        for l in languages:
            if not self.db.query(Language).filter(Language.code == l["code"]).first():
                self.db.add(Language(**l))

        # 3. Accessibility Profiles
        profiles = [
            {"key": "default", "name": "Default Profile", "description": "Standard retail screen configuration"},
            {"key": "large_text", "name": "Large Text (200%)", "description": "200% font scaling for visual accessibility"},
            {"key": "high_contrast", "name": "High Contrast", "description": "High contrast color palette for low vision"},
            {"key": "keyboard_nav", "name": "Keyboard Navigation", "description": "Focus ring indicator & tab order audit"},
            {"key": "reduced_motion", "name": "Reduced Motion", "description": "Disabled UI transitions and animations"}
        ]
        for p in profiles:
            if not self.db.query(AccessibilityProfile).filter(AccessibilityProfile.key == p["key"]).first():
                self.db.add(AccessibilityProfile(**p))

        # 4. Default Project & Screens
        proj = self.db.query(Project).filter(Project.name == "CrossSight POS Default").first()
        if not proj:
            proj = Project(name="CrossSight POS Default", description="Default Synthetic Retail POS Test Suite", version="1.0.0")
            self.db.add(proj)
            self.db.commit()
            self.db.refresh(proj)

            screens = [
                {"name": "Cashier Login", "screen_key": "login", "route_path": "?screen=login"},
                {"name": "Product Search", "screen_key": "search", "route_path": "?screen=search"},
                {"name": "Product Details", "screen_key": "details", "route_path": "?screen=details"},
                {"name": "Shopping Cart", "screen_key": "cart", "route_path": "?screen=cart"},
                {"name": "Fulfillment Checkout", "screen_key": "checkout", "route_path": "?screen=checkout"},
                {"name": "Payment Method", "screen_key": "payment", "route_path": "?screen=payment"},
                {"name": "Print Receipt", "screen_key": "receipt", "route_path": "?screen=receipt"}
            ]
            for s in screens:
                self.db.add(Screen(project_id=proj.id, **s))

        self.db.commit()

    # Log Audit Action
    def log_audit(self, user: str, action: str, entity_type: str, entity_id: str, prev_val: Optional[str] = None, new_val: Optional[str] = None, reason: Optional[str] = None):
        audit = AuditLog(
            user=user,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id),
            previous_value=prev_val,
            new_value=new_val,
            reason=reason,
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(audit)
        self.db.commit()

    # Create Baseline
    async def create_baseline_version(
        self,
        project_id: int,
        screen_key: str,
        device_key: str,
        language_code: str = "en",
        accessibility_key: str = "default",
        user: str = "QA Engineer"
    ) -> Baseline:
        # Check if baseline record exists
        baseline = self.db.query(Baseline).filter(
            Baseline.project_id == project_id,
            Baseline.screen_key == screen_key,
            Baseline.device_key == device_key,
            Baseline.language_code == language_code,
            Baseline.accessibility_key == accessibility_key
        ).first()

        if not baseline:
            baseline = Baseline(
                project_id=project_id,
                screen_key=screen_key,
                device_key=device_key,
                language_code=language_code,
                accessibility_key=accessibility_key,
                active_version="baseline-v1",
                status="ACTIVE"
            )
            self.db.add(baseline)
            self.db.commit()
            self.db.refresh(baseline)
            version_num = 1
        else:
            version_num = len(baseline.versions) + 1

        version_tag = f"baseline-v{version_num}"

        # Capture Playwright Baseline Snapshot
        snap_res = await self.runner.capture_snapshot(
            screen=screen_key,
            device_key=device_key,
            language=language_code,
            accessibility_profile=accessibility_key,
            is_baseline=True,
            version_tag=version_tag
        )

        if snap_res["status"] == "EXECUTION_FAILURE":
            raise RuntimeError(f"Failed to capture baseline: {snap_res.get('error')}")

        bv = BaselineVersion(
            baseline_id=baseline.id,
            version_tag=version_tag,
            screenshot_path=snap_res["screenshot_path"],
            accessibility_tree_path=snap_res["accessibility_path"],
            dom_metadata_path=snap_res["metadata_path"],
            created_by=user,
            approval_status="APPROVED"
        )
        self.db.add(bv)

        prev_ver = baseline.active_version
        baseline.active_version = version_tag
        self.db.commit()

        self.log_audit(
            user=user,
            action="BASELINE_CREATED",
            entity_type="Baseline",
            entity_id=str(baseline.id),
            prev_val=prev_ver,
            new_val=version_tag,
            reason="Captured reference baseline snapshot via Playwright"
        )

        return baseline

    # Rollback Baseline
    def rollback_baseline(self, req: RollbackRequest) -> Baseline:
        baseline = self.db.query(Baseline).filter(Baseline.id == req.baseline_id).first()
        if not baseline:
            raise ValueError(f"Baseline #{req.baseline_id} not found.")

        target_ver = self.db.query(BaselineVersion).filter(
            BaselineVersion.baseline_id == baseline.id,
            BaselineVersion.version_tag == req.target_version_tag
        ).first()

        if not target_ver:
            raise ValueError(f"Baseline version '{req.target_version_tag}' not found for baseline #{req.baseline_id}.")

        prev_version = baseline.active_version
        baseline.active_version = req.target_version_tag
        self.db.commit()

        # Record Rollback Event
        rb_event = RollbackEvent(
            baseline_id=baseline.id,
            previous_version_tag=prev_version,
            restored_version_tag=req.target_version_tag,
            initiated_by=req.user,
            reason=req.reason
        )
        self.db.add(rb_event)
        self.db.commit()

        self.log_audit(
            user=req.user,
            action="ROLLBACK_EXECUTED",
            entity_type="Baseline",
            entity_id=str(baseline.id),
            prev_val=prev_version,
            new_val=req.target_version_tag,
            reason=req.reason
        )

        return baseline

    # Execute Test Run
    async def run_test_suite(self, req: TestRunCreate) -> TestRun:
        test_run = TestRun(
            project_id=req.project_id,
            run_type=req.run_type,
            detector_mode=req.detector_mode,
            status="RUNNING"
        )
        self.db.add(test_run)
        self.db.commit()
        self.db.refresh(test_run)

        start_time = datetime.datetime.utcnow()

        screens = [req.screen_key] if req.screen_key else ["cart", "checkout", "payment"]
        devices = [req.device_key] if req.device_key else ["desktop_1920x1080", "tablet_1024x768"]
        langs = [req.language_code] if req.language_code else ["en", "de", "ar"]
        a11ys = [req.accessibility_key] if req.accessibility_key else ["default", "large_text"]

        total = 0
        passed = 0
        warnings = 0
        defects_count = 0

        for screen in screens:
            for dev in devices:
                for lang in langs:
                    for a11y in a11ys:
                        total += 1
                        # 1. Ensure baseline exists or create baseline
                        baseline = self.db.query(Baseline).filter(
                            Baseline.project_id == req.project_id,
                            Baseline.screen_key == screen,
                            Baseline.device_key == dev,
                            Baseline.language_code == lang,
                            Baseline.accessibility_key == a11y
                        ).first()

                        if not baseline or not baseline.versions:
                            baseline = await self.create_baseline_version(req.project_id, screen, dev, lang, a11y)

                        active_ver = self.db.query(BaselineVersion).filter(
                            BaselineVersion.baseline_id == baseline.id,
                            BaselineVersion.version_tag == baseline.active_version
                        ).first()

                        ref_snap = {
                            "screenshot_path": active_ver.screenshot_path,
                            "accessibility_path": active_ver.accessibility_tree_path,
                            "metadata_path": active_ver.dom_metadata_path
                        }

                        # 2. Render actual test snapshot
                        act_res = await self.runner.capture_snapshot(
                            screen=screen,
                            device_key=dev,
                            language=lang,
                            accessibility_profile=a11y
                        )

                        if act_res["status"] == "EXECUTION_FAILURE":
                            # Rule 6: Execution failure handling
                            snap = ActualSnapshot(
                                test_run_id=test_run.id,
                                screen_key=screen,
                                device_key=dev,
                                language_code=lang,
                                accessibility_key=a11y,
                                status="EXECUTION_FAILURE"
                            )
                            self.db.add(snap)
                            continue

                        snap = ActualSnapshot(
                            test_run_id=test_run.id,
                            screen_key=screen,
                            device_key=dev,
                            language_code=lang,
                            accessibility_key=a11y,
                            screenshot_path=act_res["screenshot_path"],
                            accessibility_tree_path=act_res["accessibility_path"],
                            dom_metadata_path=act_res["metadata_path"],
                            status="SUCCESS"
                        )
                        self.db.add(snap)
                        self.db.commit()
                        self.db.refresh(snap)

                        diff_output = os.path.join(self.artifact_dir, "diffs", f"diff_run{test_run.id}_{screen}_{dev}.png")

                        # 3. Run Selected Detector (PIXEL vs HYBRID)
                        if req.detector_mode == "PIXEL":
                            det_res = self.pixel_detector.compare_screenshots(
                                ref_snap["screenshot_path"],
                                act_res["screenshot_path"],
                                diff_output
                            )
                            score = det_res["visual_score"]
                            classification = det_res["classification"]
                            severity = "HIGH" if classification == "DEFECT_CANDIDATE" else "NONE"
                            explanation = f"Pixel SSIM Mismatch detected (SSIM: {det_res['ssim_score']}, Diff: {det_res['difference_percentage']}%)."
                            detected_defects = []
                        else: # HYBRID
                            det_res = self.hybrid_detector.run_hybrid_detection(
                                ref_snap,
                                act_res,
                                diff_output
                            )
                            score = det_res["overall_regression_score"]
                            classification = det_res["classification"]
                            severity = det_res["severity"]
                            explanation = det_res["explanation"]
                            detected_defects = det_res.get("detected_defects", [])

                        if classification == "PASS":
                            passed += 1
                        elif classification == "WARNING":
                            warnings += 1
                        else:
                            defects_count += 1
                            # Record Defect
                            defect_code = f"DEF-{test_run.id:03d}-{defects_count:02d}"
                            df = Defect(
                                defect_code=defect_code,
                                actual_snapshot_id=snap.id,
                                baseline_version_tag=baseline.active_version,
                                detector_mode=req.detector_mode,
                                defect_type=det_res.get("primary_defect_type", "REGRESSION"),
                                severity=severity,
                                classification=classification,
                                review_status="PENDING",
                                overall_regression_score=det_res.get("overall_regression_score", score),
                                visual_score=det_res.get("visual_score", score),
                                ssim_score=det_res.get("ssim_score", score),
                                geometry_score=det_res.get("geometry_score", 1.0),
                                accessibility_score=det_res.get("accessibility_score", 1.0),
                                localization_score=det_res.get("localization_score", 1.0),
                                explanation=explanation
                            )
                            self.db.add(df)
                            self.db.commit()
                            self.db.refresh(df)

                            # Generate Evidence Package for HIGH & CRITICAL findings
                            if severity in ["CRITICAL", "HIGH"]:
                                ev_pkg = self.evidence_generator.create_evidence_package(
                                    defect_code,
                                    ref_snap,
                                    act_res,
                                    det_res,
                                    baseline.active_version
                                )
                                ev = Evidence(
                                    defect_id=df.id,
                                    reference_screenshot_path=ev_pkg["reference_screenshot_path"],
                                    actual_screenshot_path=ev_pkg["actual_screenshot_path"],
                                    diff_image_path=ev_pkg["diff_image_path"],
                                    highlighted_region_path=ev_pkg["highlighted_region_path"],
                                    geometry_evidence={"score": det_res.get("geometry_score")},
                                    accessibility_diff={"score": det_res.get("accessibility_score")},
                                    detector_metadata=ev_pkg["detector_scores"]
                                )
                                self.db.add(ev)
                                self.db.commit()

        test_run.status = "COMPLETED"
        test_run.total_scenarios = total
        test_run.passed_count = passed
        test_run.warning_count = warnings
        test_run.defect_count = defects_count
        test_run.execution_time_ms = (datetime.datetime.utcnow() - start_time).total_seconds() * 1000.0
        self.db.commit()

        self.log_audit(
            user="System Runner",
            action="TEST_COMPLETED",
            entity_type="TestRun",
            entity_id=str(test_run.id),
            reason=f"Completed {total} test scenarios. Passed: {passed}, Defects: {defects_count}"
        )

        return test_run

    # Defect Review Action
    def review_defect(self, defect_id: int, req: DefectReviewRequest) -> Defect:
        defect = self.db.query(Defect).filter(Defect.id == defect_id).first()
        if not defect:
            raise ValueError(f"Defect #{defect_id} not found.")

        # Rule 7: HIGH and CRITICAL defects require human review!
        prev_status = defect.review_status
        defect.review_status = req.action
        if req.action == "APPROVED":
            defect.classification = "TRUE_DEFECT"
        elif req.action == "REJECTED":
            defect.classification = "ACCEPTABLE_VARIATION"

        review = Review(
            defect_id=defect.id,
            reviewer_name=req.reviewer_name,
            action=req.action,
            notes=req.notes
        )
        self.db.add(review)
        self.db.commit()

        self.log_audit(
            user=req.reviewer_name,
            action=f"DEFECT_{req.action}",
            entity_type="Defect",
            entity_id=str(defect.id),
            prev_val=prev_status,
            new_val=req.action,
            reason=req.notes
        )

        return defect
