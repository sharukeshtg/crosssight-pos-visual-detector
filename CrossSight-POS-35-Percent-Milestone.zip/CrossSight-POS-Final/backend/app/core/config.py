from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "CrossSight POS Platform"
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"

    DATABASE_URL: str = "sqlite:///./crosssight.db"

    ARTIFACT_DIR: str = "./artifacts"
    BASELINE_DIR: str = "./artifacts/baselines"
    SCREENSHOT_DIR: str = "./artifacts/screenshots"
    ACCESSIBILITY_DIR: str = "./artifacts/accessibility"
    EVIDENCE_DIR: str = "./artifacts/evidence"

    POS_APP_URL: str = "http://127.0.0.1:8000/pos-app/index.html"

    SECRET_KEY: str = "change-me-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
