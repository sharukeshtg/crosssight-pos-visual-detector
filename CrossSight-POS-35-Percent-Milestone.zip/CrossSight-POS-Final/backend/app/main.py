import os
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from backend.app.core.config import settings
from backend.app.core.database import get_db, engine, Base
from backend.app.models.models import (
    Project, Screen, Device, Language, AccessibilityProfile,
    Baseline, TestRun, Defect, Evidence, AuditLog, BaselineVersion
)
from backend.app.schemas.schemas import (
    ProjectCreate, ProjectResponse, ScreenResponse, DeviceResponse,
    LanguageResponse, AccessibilityProfileResponse, BaselineResponse,
    TestRunCreate, TestRunResponse, DefectResponse, EvidenceResponse,
    DefectReviewRequest, AuditLogResponse, RollbackRequest
)
from backend.app.services.services import PlatformService
from experiments.run_experiments import run_comparative_experiment

# Initialize DB Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url="/api/openapi.json"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Synthetic POS Application
pos_dir = os.path.abspath("./pos-app")
if os.path.exists(pos_dir):
    app.mount("/pos-app", StaticFiles(directory=pos_dir, html=True), name="pos-app")

# Mount Artifacts Storage
artifact_dir = os.path.abspath(settings.ARTIFACT_DIR)
os.makedirs(artifact_dir, exist_ok=True)
app.mount("/artifacts", StaticFiles(directory=artifact_dir), name="artifacts")

# Startup Seed Master Data
@app.on_event("startup")
def startup_event():
    db = next(get_db())
    service = PlatformService(db)
    service.seed_master_data()

# 1. Health Check
@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": settings.PROJECT_NAME, "version": settings.VERSION}

# 2. Projects
@app.get("/api/projects", response_model=List[ProjectResponse])
def get_projects(db: Session = Depends(get_db)):
    return db.query(Project).all()

@app.post("/api/projects", response_model=ProjectResponse)
def create_project(req: ProjectCreate, db: Session = Depends(get_db)):
    proj = Project(name=req.name, description=req.description, version=req.version)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return proj

# 3. Screens
@app.get("/api/screens", response_model=List[ScreenResponse])
def get_screens(db: Session = Depends(get_db)):
    return db.query(Screen).all()

# 4. Devices
@app.get("/api/devices", response_model=List[DeviceResponse])
def get_devices(db: Session = Depends(get_db)):
    return db.query(Device).all()

# 5. Languages
@app.get("/api/languages", response_model=List[LanguageResponse])
def get_languages(db: Session = Depends(get_db)):
    return db.query(Language).all()

# 6. Accessibility Profiles
@app.get("/api/accessibility-profiles", response_model=List[AccessibilityProfileResponse])
def get_accessibility_profiles(db: Session = Depends(get_db)):
    return db.query(AccessibilityProfile).all()

# 7. Baselines & Rollback
@app.get("/api/baselines", response_model=List[BaselineResponse])
def get_baselines(db: Session = Depends(get_db)):
    return db.query(Baseline).all()

@app.post("/api/baselines")
async def create_baseline(
    project_id: int = Query(...),
    screen_key: str = Query(...),
    device_key: str = Query(...),
    language_code: str = Query("en"),
    accessibility_key: str = Query("default"),
    db: Session = Depends(get_db)
):
    service = PlatformService(db)
    baseline = await service.create_baseline_version(project_id, screen_key, device_key, language_code, accessibility_key)
    return {"status": "ok", "baseline_id": baseline.id, "active_version": baseline.active_version}

@app.post("/api/baselines/rollback")
def rollback_baseline(req: RollbackRequest, db: Session = Depends(get_db)):
    service = PlatformService(db)
    try:
        baseline = service.rollback_baseline(req)
        return {"status": "ok", "baseline_id": baseline.id, "active_version": baseline.active_version}
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))

# 8. Test Runs
@app.get("/api/test-runs", response_model=List[TestRunResponse])
def get_test_runs(db: Session = Depends(get_db)):
    return db.query(TestRun).order_by(TestRun.id.desc()).all()

@app.post("/api/test-runs", response_model=TestRunResponse)
async def trigger_test_run(req: TestRunCreate, db: Session = Depends(get_db)):
    service = PlatformService(db)
    test_run = await service.run_test_suite(req)
    return test_run

# 9. Defects & Human Review
@app.get("/api/defects", response_model=List[DefectResponse])
def get_defects(
    severity: Optional[str] = None,
    review_status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Defect)
    if severity:
        query = query.filter(Defect.severity == severity)
    if review_status:
        query = query.filter(Defect.review_status == review_status)
    return query.order_by(Defect.id.desc()).all()

@app.get("/api/defects/{defect_id}", response_model=DefectResponse)
def get_defect_details(defect_id: int, db: Session = Depends(get_db)):
    defect = db.query(Defect).filter(Defect.id == defect_id).first()
    if not defect:
        raise HTTPException(status_code=404, detail="Defect not found")
    return defect

@app.post("/api/defects/{defect_id}/review", response_model=DefectResponse)
def review_defect(defect_id: int, req: DefectReviewRequest, db: Session = Depends(get_db)):
    service = PlatformService(db)
    try:
        defect = service.review_defect(defect_id, req)
        return defect
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))

# 10. Evidence
@app.get("/api/evidence/{defect_id}", response_model=EvidenceResponse)
def get_evidence(defect_id: int, db: Session = Depends(get_db)):
    ev = db.query(Evidence).filter(Evidence.defect_id == defect_id).first()
    if not ev:
        raise HTTPException(status_code=404, detail="Evidence package not found")
    return ev

# 11. Audit Logs
@app.get("/api/audit-logs", response_model=List[AuditLogResponse])
def get_audit_logs(db: Session = Depends(get_db)):
    return db.query(AuditLog).order_by(AuditLog.id.desc()).all()

# 12. Experimental Benchmarking API
@app.post("/api/experiments/run")
async def run_experiment_api(db: Session = Depends(get_db)):
    res = await run_comparative_experiment()
    return res

# Mount Frontend Dashboard at Root (Must be mounted last to allow API routes precedence)
frontend_dir = os.path.abspath("./frontend")
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")
