# CrossSight POS

CrossSight POS is a minimum viable visual and accessibility regression detection platform for a retail point-of-sale application. It tests the same POS workflow across viewport/device configurations, languages, and accessibility profiles.

## Architecture

- **POS demo:** `pos-app/` — deterministic synthetic retail POS screens with controlled defect injection.
- **Frontend dashboard:** `frontend/` — test runs, defects, evidence, baselines, audit logs, and experiment controls.
- **Backend:** `backend/` — FastAPI REST API + SQLAlchemy persistence.
- **Detection engine:** `engine/` — pixel/SSIM, DOM geometry, accessibility, localization, evidence, and hybrid scoring.
- **Experiments:** `experiments/` — 16-case ground-truth benchmark comparing pixel-only and hybrid detection.
- **Tests:** `tests/` — backend and engine unit tests.
- **Artifacts:** `artifacts/` — screenshots and generated evidence.

## Quick start (Windows PowerShell)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
python -m uvicorn backend.app.main:app --reload --port 8000
```

Open `http://127.0.0.1:8000/` for the dashboard and `http://127.0.0.1:8000/pos-app/` for the POS demo.

## Run tests

```powershell
python -m pytest tests/ -q
```

## Run the comparative benchmark

Start the API first, then run:

```powershell
python -m experiments.run_experiments
```

The benchmark evaluates 16 controlled scenarios and writes `experiments/results/experiment_results.json`. It intentionally fails instead of producing misleading zero metrics if Playwright cannot execute any scenario.

## Docker

```powershell
docker compose up --build
```

The container installs Chromium and serves the dashboard on port 8000.

## Main API endpoints

- `GET /api/health`
- `GET /api/projects`
- `GET /api/screens`
- `GET /api/devices`
- `GET /api/languages`
- `GET /api/accessibility-profiles`
- `GET /api/baselines`
- `POST /api/baselines`
- `POST /api/baselines/rollback`
- `GET /api/test-runs`
- `POST /api/test-runs`
- `GET /api/defects`
- `GET /api/defects/{id}`
- `POST /api/defects/{id}/review`
- `GET /api/evidence/{defect_id}`
- `GET /api/audit-logs`
- `POST /api/experiments/run`

## Ground-truth result already included

The repository contains previously generated screenshot artifacts and a benchmark result from the Antigravity run. Those artifacts are useful evidence for a college demonstration. Re-run the benchmark after installing Chromium to regenerate fresh measurements.
