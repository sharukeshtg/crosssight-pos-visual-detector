/* CrossSight POS Synthetic Retail Application Logic */

(function () {
  'use strict';

  // Sample Retail Product Catalog
  const PRODUCTS = [
    { id: 'SKU-101', name: 'Barcode Scanner Pro Wireless', price: 149.99, category: 'electronics' },
    { id: 'SKU-102', name: 'Thermal Receipt Paper (Pack of 10)', price: 24.50, category: 'grocery' },
    { id: 'SKU-103', name: 'Heavy Duty Cash Drawer RJ11', price: 89.00, category: 'electronics' },
    { id: 'SKU-104', name: 'Retail Store Polo Shirt (Size L)', price: 35.00, category: 'apparel' },
    { id: 'SKU-105', name: 'Customer Facing 10" Display Touchscreen', price: 299.00, category: 'electronics' },
    { id: 'SKU-106', name: 'Organic Fairtrade Coffee Beans (1kg)', price: 18.75, category: 'grocery' }
  ];

  // Multi-Language Dictionary
  const TRANSLATIONS = {
    en: {
      brand: "CrossSight POS",
      terminalId: "Terminal #104",
      loginTitle: "Cashier Login",
      loginSub: "Enter credentials to open retail register session",
      labelPin: "Cashier PIN",
      labelRegister: "Register ID",
      btnOpen: "Open Register Session",
      cartTitle: "Cart Items",
      summaryTitle: "Order Summary",
      subtotal: "Subtotal",
      tax: "Tax (8%)",
      discount: "Discount",
      total: "Total Amount",
      btnCheckout: "Proceed to Checkout",
      btnPayment: "Proceed to Payment",
      btnComplete: "Complete Transaction & Print Receipt"
    },
    de: {
      brand: "CrossSight POS - System",
      terminalId: "Kassenplatz #104",
      loginTitle: "Kassierer-Anmeldung",
      loginSub: "Geben Sie Ihre Zugangsdaten ein, um die Kassen-Sitzung zu öffnen",
      labelPin: "Kassierer-PIN-Nummer",
      labelRegister: "Kassen-Identifikationsnummer",
      btnOpen: "Kassen-Sitzung Öffnen",
      cartTitle: "Warenkorbpositionen",
      summaryTitle: "Bestellzusammenfassung",
      subtotal: "Zwischensumme",
      tax: "Mehrwertsteuer (8%)",
      discount: "Rabattabzug",
      total: "Gesamtsumme",
      btnCheckout: "Weiter zur Zahlungsabwicklung", // Long translation for overflow testing!
      btnPayment: "Weiter zur Transaktionsbestätigung und Bezahlung", // Long translation!
      btnComplete: "Transaktion Abschließen und Kassenbon Drucken"
    },
    ar: {
      brand: "نقطة بيع كروس سايت",
      terminalId: "جهاز رقم #104",
      loginTitle: "تسجيل دخول أمين الصندوق",
      loginSub: "أدخل بيانات الاعتماد لفتح جلسة التسجيل",
      labelPin: "رمز PIN الصراف",
      labelRegister: "معرف الصندوق",
      btnOpen: "فتح جلسة الصندوق",
      cartTitle: "عناصر السلة",
      summaryTitle: "ملخص الطلب",
      subtotal: "المجموع الفرعي",
      tax: "الضريبة (8%)",
      discount: "الخصم",
      total: "المبلغ الإجمالي",
      btnCheckout: "المتابعة إلى الدفع",
      btnPayment: "المتابعة إلى عملية الإتمام",
      btnComplete: "إكمال المعاملة وطباعة الإيصال"
    },
    ta: {
      brand: "க்ராஸ்ஸைட் பிஓஎஸ்",
      terminalId: "முனையம் #104",
      loginTitle: "காசாளர் உள்நுழைவு",
      loginSub: "விற்பனை அமர்வைத் தொடங்க விவரங்களை உள்ளிடவும்",
      labelPin: "காசாளர் பின்",
      labelRegister: "பதிவு எண்",
      btnOpen: "விற்பனை அமர்வைத் தொடங்கு",
      cartTitle: "வண்டி பொருட்கள்",
      summaryTitle: "ஆர்டர் சுருக்கம்",
      subtotal: "உப மொத்தம்",
      tax: "வரி (8%)",
      discount: "தள்ளுபடி",
      total: "மொத்த தொகை",
      btnCheckout: "செக்அவுட்டிற்குச் செல்",
      btnPayment: "பணம் செலுத்துதலுக்குச் செல்",
      btnComplete: "பரிவர்த்தனையை முடித்து ரசீது அச்சிடு"
    },
    hi: {
      brand: "क्रॉससाइट पीओएस",
      terminalId: "टर्मिनल #104",
      loginTitle: "कैशियर लॉगिन",
      loginSub: "रजिस्टर सत्र शुरू करने के लिए क्रेडेंशियल दर्ज करें",
      labelPin: "कैशियर पिन",
      labelRegister: "रजिस्टर आईडी",
      btnOpen: "रजिस्टर सत्र शुरू करें",
      cartTitle: "कार्ट आइटम",
      summaryTitle: "ऑर्डर सारांश",
      subtotal: "उपयोग कुल",
      tax: "कर (8%)",
      discount: "छूट",
      total: "कुल राशि",
      btnCheckout: "चेकआउट के लिए आगे बढ़ें",
      btnPayment: "भुगतान के लिए आगे बढ़ें",
      btnComplete: "लेन-देन पूरा करें और रसीद प्रिंट करें"
    }
  };

  // State Management
  let cartState = [
    { product: PRODUCTS[0], qty: 1 },
    { product: PRODUCTS[1], qty: 2 }
  ];
  let currentLang = 'en';
  let currentA11y = 'default';
  let activeScreen = 'login';
  let activeDefect = null;

  // DOM Elements
  const langSelect = document.getElementById('lang-select');
  const a11ySelect = document.getElementById('a11y-select');
  const navBtns = document.querySelectorAll('.nav-btn');
  const posScreens = document.querySelectorAll('.pos-screen');
  const productGrid = document.getElementById('product-grid');
  const cartTbody = document.getElementById('cart-tbody');
  const cartCount = document.getElementById('cart-count');
  const defectStatus = document.getElementById('defect-status');

  // Initialize POS
  function init() {
    parseUrlParams();
    renderProducts();
    renderCart();
    attachEventListeners();
    applyLanguage(currentLang);
    applyAccessibility(currentA11y);
    applyDefect(activeDefect);
  }

  // Parse URL Parameters (screen, lang, a11y, defect)
  function parseUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('lang')) currentLang = params.get('lang');
    if (params.has('a11y')) currentA11y = params.get('a11y');
    if (params.has('screen')) activeScreen = params.get('screen');
    if (params.has('defect')) activeDefect = params.get('defect');

    if (langSelect) langSelect.value = currentLang;
    if (a11ySelect) a11ySelect.value = currentA11y;
  }

  // Screen Switcher
  function switchScreen(screenName) {
    activeScreen = screenName;
    posScreens.forEach(screen => {
      if (screen.id === `screen-${screenName}`) {
        screen.classList.add('active');
      } else {
        screen.classList.remove('active');
      }
    });

    navBtns.forEach(btn => {
      if (btn.dataset.screen === screenName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    if (screenName === 'details') renderProductDetails(PRODUCTS[0]);
    if (screenName === 'receipt') renderReceipt();
  }

  // Render Product Cards
  function renderProducts() {
    if (!productGrid) return;
    productGrid.innerHTML = PRODUCTS.map(prod => `
      <div class="product-card">
        <div>
          <div class="product-title">${prod.name}</div>
          <div class="product-sku">SKU: ${prod.id}</div>
        </div>
        <div class="product-price-row">
          <span class="product-price">$${prod.price.toFixed(2)}</span>
          <button class="btn btn-sm btn-primary btn-add-cart" data-id="${prod.id}">+ Add</button>
        </div>
      </div>
    `).join('');
  }

  // Render Shopping Cart
  function renderCart() {
    if (!cartTbody) return;
    let subtotal = 0;
    let totalItems = 0;

    cartTbody.innerHTML = cartState.map((item, idx) => {
      const itemTotal = item.product.price * item.qty;
      subtotal += itemTotal;
      totalItems += item.qty;
      return `
        <tr>
          <td><strong>${item.product.name}</strong><br><small class="text-muted">${item.product.id}</small></td>
          <td>$${item.product.price.toFixed(2)}</td>
          <td>${item.qty}</td>
          <td>$${itemTotal.toFixed(2)}</td>
          <td><button class="btn btn-sm btn-outline btn-remove" data-idx="${idx}">Remove</button></td>
        </tr>
      `;
    }).join('');

    const tax = subtotal * 0.08;
    const discount = subtotal > 150 ? 15.00 : 0.00;
    const grandTotal = Math.max(0, subtotal + tax - discount);

    if (cartCount) cartCount.textContent = totalItems;
    const subEl = document.getElementById('summary-subtotal');
    const taxEl = document.getElementById('summary-tax');
    const discEl = document.getElementById('summary-discount');
    const totEl = document.getElementById('summary-total');
    const payTotEl = document.getElementById('checkout-payable-total');
    const payDueEl = document.getElementById('payment-amount-due');

    if (subEl) subEl.textContent = `$${subtotal.toFixed(2)}`;
    if (taxEl) taxEl.textContent = `$${tax.toFixed(2)}`;
    if (discEl) discEl.textContent = `-$${discount.toFixed(2)}`;
    if (totEl) totEl.textContent = `$${grandTotal.toFixed(2)}`;
    if (payTotEl) payTotEl.textContent = `$${grandTotal.toFixed(2)}`;
    if (payDueEl) payDueEl.textContent = `$${grandTotal.toFixed(2)}`;
  }

  // Render Product Details
  function renderProductDetails(prod) {
    const card = document.getElementById('product-details-card');
    if (!card) return;
    card.innerHTML = `
      <h2>${prod.name}</h2>
      <p class="text-muted">SKU Reference: ${prod.id} | Category: ${prod.category.toUpperCase()}</p>
      <hr class="divider">
      <p>High quality retail inventory unit for point-of-sale store management.</p>
      <div class="product-price-row" style="margin-top: 1.5rem;">
        <span class="product-price" style="font-size: 1.6rem;">$${prod.price.toFixed(2)}</span>
        <button class="btn btn-primary btn-lg" id="btn-details-add">Add to Active Cart</button>
      </div>
    `;
  }

  // Render Receipt
  function renderReceipt() {
    const list = document.getElementById('receipt-items-list');
    if (!list) return;
    let subtotal = 0;
    list.innerHTML = cartState.map(item => {
      const lineTotal = item.product.price * item.qty;
      subtotal += lineTotal;
      return `<div class="receipt-line"><span>${item.qty}x ${item.product.name}</span><span>$${lineTotal.toFixed(2)}</span></div>`;
    }).join('');

    const tax = subtotal * 0.08;
    const grandTotal = subtotal + tax;

    const subEl = document.getElementById('receipt-subtotal');
    const taxEl = document.getElementById('receipt-tax');
    const totEl = document.getElementById('receipt-total');

    if (subEl) subEl.textContent = `$${subtotal.toFixed(2)}`;
    if (taxEl) taxEl.textContent = `$${tax.toFixed(2)}`;
    if (totEl) totEl.textContent = `$${grandTotal.toFixed(2)}`;
  }

  // Language Dictionary Application
  function applyLanguage(lang) {
    currentLang = lang;
    document.documentElement.lang = lang;

    // Handle Arabic RTL
    if (lang === 'ar') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }

    const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
    Object.keys(dict).forEach(key => {
      const el = document.getElementById(`t-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`);
      if (el) el.textContent = dict[key];
    });
  }

  // Accessibility Profile Application
  function applyAccessibility(profile) {
    currentA11y = profile;
    document.documentElement.setAttribute('data-theme', profile);
  }

  // Defect Injection Logic
  function applyDefect(defect) {
    activeDefect = defect;
    if (!defect) {
      document.body.removeAttribute('data-defect');
      if (defectStatus) defectStatus.textContent = "NONE";
      return;
    }

    document.body.setAttribute('data-defect', defect);
    if (defectStatus) defectStatus.textContent = defect.toUpperCase();

    // Defect-specific DOM manipulations
    if (defect === 'missing_aria_label') {
      const btn = document.getElementById('btn-proceed-payment');
      if (btn) btn.removeAttribute('aria-label');
    }
    if (defect === 'role_mismatch') {
      const btn = document.getElementById('btn-proceed-checkout');
      if (btn) btn.setAttribute('role', 'paragraph');
    }
  }

  // Attach Event Listeners
  function attachEventListeners() {
    if (langSelect) langSelect.addEventListener('change', e => applyLanguage(e.target.value));
    if (a11ySelect) a11ySelect.addEventListener('change', e => applyAccessibility(e.target.value));

    navBtns.forEach(btn => {
      btn.addEventListener('click', () => switchScreen(btn.dataset.screen));
    });

    const btnLoginSubmit = document.getElementById('btn-login-submit');
    if (btnLoginSubmit) btnLoginSubmit.addEventListener('click', () => switchScreen('search'));

    const btnProceedCheckout = document.getElementById('btn-proceed-checkout');
    if (btnProceedCheckout) btnProceedCheckout.addEventListener('click', () => switchScreen('checkout'));

    const btnProceedPayment = document.getElementById('btn-proceed-payment');
    if (btnProceedPayment) btnProceedPayment.addEventListener('click', () => switchScreen('payment'));

    const btnSubmitPayment = document.getElementById('btn-submit-payment');
    if (btnSubmitPayment) btnSubmitPayment.addEventListener('click', () => switchScreen('receipt'));

    const btnNewSale = document.getElementById('btn-new-sale');
    if (btnNewSale) btnNewSale.addEventListener('click', () => switchScreen('search'));

    document.addEventListener('click', e => {
      if (e.target.classList.contains('btn-add-cart')) {
        const prodId = e.target.dataset.id;
        const prod = PRODUCTS.find(p => p.id === prodId);
        if (prod) {
          const existing = cartState.find(c => c.product.id === prodId);
          if (existing) existing.qty += 1;
          else cartState.push({ product: prod, qty: 1 });
          renderCart();
        }
      }
    });

    switchScreen(activeScreen);
  }

  // Global Export
  window.CrossSightPOS = {
    switchScreen,
    applyLanguage,
    applyAccessibility,
    applyDefect,
    PRODUCTS,
    TRANSLATIONS
  };

  document.addEventListener('DOMContentLoaded', init);
})();
