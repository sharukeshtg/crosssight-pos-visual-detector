import math
from typing import Dict, Any, List, Optional, Tuple


class AccessibilityDetector:
    """
    Approach B Component: Accessibility Tree & WCAG Rule Audit Engine.
    Inspects accessibility snapshots, roles, accessible names, focusability,
    touch target bounds, color contrast ratios, font size regressions,
    focus order sequences, and tab order continuity.

    Covers Defect Types:
    - ACCESSIBLE_NAME_MISSING
    - ROLE_MISMATCH
    - CONTROL_TOO_SMALL
    - KEYBOARD_ACCESSIBILITY_FAILURE
    - COLOR_CONTRAST_ERROR       (WCAG 2.1 AA §1.4.3)
    - FONT_SIZE_REGRESSION        (Unexpected font size deviation from baseline)
    - FOCUS_ORDER_REGRESSION      (Logical focus order violated)
    - TAB_ORDER_REGRESSION        (Tab index sequence produces unreachable or mis-ordered controls)
    """

    # WCAG 2.1 AA minimum contrast ratios
    CONTRAST_RATIO_NORMAL_TEXT = 4.5    # For text < 18pt (or < 14pt bold)
    CONTRAST_RATIO_LARGE_TEXT = 3.0     # For text >= 18pt (or >= 14pt bold)
    FONT_SIZE_DEVIATION_THRESHOLD = 0.20  # 20% deviation from baseline triggers regression

    def compare_accessibility_tree(
        self,
        reference_tree: Dict[str, Any],
        actual_tree: Dict[str, Any],
        dom_nodes: List[Dict[str, Any]],
        reference_dom_nodes: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Analyzes actual accessibility tree and DOM metadata against accessibility standards.
        Detects missing accessible names, role mismatches, non-focusable controls,
        small touch targets, color contrast violations, font size regressions,
        and focus/tab order regressions.

        Parameters:
            reference_tree: Accessibility snapshot from baseline render.
            actual_tree: Accessibility snapshot from actual (test) render.
            dom_nodes: DOM element metadata list from actual render.
            reference_dom_nodes: DOM element metadata list from reference render (optional, for regression comparison).
        """
        accessibility_defects: List[Dict[str, Any]] = []

        # Build reference DOM lookup for regression comparison
        ref_dom_map: Dict[str, Dict[str, Any]] = {}
        if reference_dom_nodes:
            for node in reference_dom_nodes:
                key = node.get("id") or f"{node.get('tag', '')}_{node.get('text', '')[:20]}"
                ref_dom_map[key] = node

        # 1. Audit Interactive DOM Elements for WCAG & A11y Standards
        for node in dom_nodes:
            tag = node.get("tag", "")
            role = node.get("role", "")
            aria_label = node.get("ariaLabel", "")
            text = node.get("text", "")
            bounds = node.get("bounds", {"width": 0, "height": 0})
            node_id = node.get("id", tag)
            node_key = node.get("id") or f"{tag}_{text[:20]}"

            # Check 1: Missing Accessible Name on Interactive Controls
            if tag in ["button", "input", "select", "a"] or role in ["button", "link", "textbox"]:
                has_name = bool(aria_label or text)
                if not has_name:
                    accessibility_defects.append({
                        "defect_type": "ACCESSIBLE_NAME_MISSING",
                        "severity": "HIGH",
                        "element_id": node_id,
                        "element_tag": tag,
                        "explanation": f"Interactive control <{tag} id='{node_id}'> has no accessible name or aria-label."
                    })

            # Check 2: Role Mismatch (e.g. button rendered with role='paragraph')
            if tag == "button" and role not in ["button", "link"]:
                accessibility_defects.append({
                    "defect_type": "ROLE_MISMATCH",
                    "severity": "HIGH",
                    "element_id": node_id,
                    "element_tag": tag,
                    "explanation": f"Button element <{tag} id='{node_id}'> has non-standard role='{role}'."
                })

            # Check 3: Touch Target Size (WCAG 2.1 AA 2.5.5 - minimum 44x44px for buttons)
            if tag == "button" or role == "button":
                if bounds["width"] < 44 or bounds["height"] < 44:
                    accessibility_defects.append({
                        "defect_type": "CONTROL_TOO_SMALL",
                        "severity": "MEDIUM",
                        "element_id": node_id,
                        "element_tag": tag,
                        "explanation": f"Button touch target is too small ({bounds['width']}x{bounds['height']}px). WCAG minimum is 44x44px."
                    })

            # Check 4: Keyboard Focusability
            if (tag in ["button", "input"] or role == "button") and not node.get("focusable", False):
                accessibility_defects.append({
                    "defect_type": "KEYBOARD_ACCESSIBILITY_FAILURE",
                    "severity": "CRITICAL",
                    "element_id": node_id,
                    "element_tag": tag,
                    "explanation": f"Interactive element <{tag} id='{node_id}'> is not focusable via keyboard navigation."
                })

            # Check 5: COLOR_CONTRAST_ERROR (WCAG 2.1 AA §1.4.3)
            fg_color = node.get("color")
            bg_color = node.get("backgroundColor")
            font_size_px = node.get("fontSize", 16)

            if fg_color and bg_color:
                contrast_ratio = self._compute_contrast_ratio(fg_color, bg_color)
                is_large_text = font_size_px >= 24 or (font_size_px >= 18.66 and node.get("fontWeight", 400) >= 700)
                required_ratio = self.CONTRAST_RATIO_LARGE_TEXT if is_large_text else self.CONTRAST_RATIO_NORMAL_TEXT

                if contrast_ratio < required_ratio:
                    accessibility_defects.append({
                        "defect_type": "COLOR_CONTRAST_ERROR",
                        "severity": "HIGH",
                        "element_id": node_id,
                        "element_tag": tag,
                        "measured_ratio": round(contrast_ratio, 2),
                        "required_ratio": required_ratio,
                        "foreground": fg_color,
                        "background": bg_color,
                        "explanation": (
                            f"Color contrast ratio {contrast_ratio:.2f}:1 is below WCAG AA "
                            f"minimum {required_ratio}:1 for "
                            f"{'large' if is_large_text else 'normal'} text on "
                            f"<{tag} id='{node_id}'>. "
                            f"Foreground: {fg_color}, Background: {bg_color}."
                        )
                    })

            # Check 6: FONT_SIZE_REGRESSION (Baseline Comparison)
            if reference_dom_nodes and node_key in ref_dom_map:
                ref_node = ref_dom_map[node_key]
                ref_font_size = ref_node.get("fontSize", 16)
                act_font_size = node.get("fontSize", 16)

                if ref_font_size > 0 and act_font_size > 0:
                    deviation = abs(act_font_size - ref_font_size) / ref_font_size
                    if deviation > self.FONT_SIZE_DEVIATION_THRESHOLD:
                        accessibility_defects.append({
                            "defect_type": "FONT_SIZE_REGRESSION",
                            "severity": "MEDIUM" if deviation < 0.5 else "HIGH",
                            "element_id": node_id,
                            "element_tag": tag,
                            "reference_font_size": ref_font_size,
                            "actual_font_size": act_font_size,
                            "deviation_pct": round(deviation * 100, 2),
                            "explanation": (
                                f"Font size regression on <{tag} id='{node_id}'>: "
                                f"baseline={ref_font_size}px, actual={act_font_size}px "
                                f"({deviation * 100:.1f}% deviation exceeds {self.FONT_SIZE_DEVIATION_THRESHOLD * 100:.0f}% threshold)."
                            )
                        })

        # Check 7: FOCUS_ORDER_REGRESSION
        # Compare logical focus order sequences between reference and actual accessibility trees
        ref_focus_order = self._extract_focus_order(reference_tree)
        act_focus_order = self._extract_focus_order(actual_tree)

        if ref_focus_order and act_focus_order:
            focus_order_issues = self._compare_focus_order(ref_focus_order, act_focus_order)
            for issue in focus_order_issues:
                accessibility_defects.append({
                    "defect_type": "FOCUS_ORDER_REGRESSION",
                    "severity": "HIGH",
                    "element_id": issue.get("element", "unknown"),
                    "reference_position": issue.get("ref_position"),
                    "actual_position": issue.get("act_position"),
                    "explanation": issue["explanation"]
                })

        # Check 8: TAB_ORDER_REGRESSION
        # Validate tab index sequence for gaps, duplicates, and unreachable elements
        tab_order_issues = self._validate_tab_order(dom_nodes, ref_dom_map)
        for issue in tab_order_issues:
            accessibility_defects.append({
                "defect_type": "TAB_ORDER_REGRESSION",
                "severity": issue.get("severity", "HIGH"),
                "element_id": issue.get("element_id", "unknown"),
                "explanation": issue["explanation"]
            })

        # Calculate Accessibility Score (1.0 = fully accessible, 0.0 = total a11y breakdown)
        # Weight by severity: CRITICAL=0.30, HIGH=0.20, MEDIUM=0.10, LOW=0.05
        score_penalty = 0.0
        for d in accessibility_defects:
            sev = d.get("severity", "LOW")
            if sev == "CRITICAL":
                score_penalty += 0.30
            elif sev == "HIGH":
                score_penalty += 0.20
            elif sev == "MEDIUM":
                score_penalty += 0.10
            else:
                score_penalty += 0.05
        accessibility_score = max(0.0, 1.0 - score_penalty)

        return {
            "accessibility_score": round(accessibility_score, 4),
            "accessibility_defects": accessibility_defects,
            "total_nodes_audited": len(dom_nodes),
            "focus_order_ref_count": len(ref_focus_order) if ref_focus_order else 0,
            "focus_order_act_count": len(act_focus_order) if act_focus_order else 0,
            "defect_type_summary": self._summarize_defect_types(accessibility_defects)
        }

    # ─── Color Contrast Helpers ───────────────────────────────────────────

    def _compute_contrast_ratio(self, fg: str, bg: str) -> float:
        """
        Computes WCAG contrast ratio between foreground and background colors.
        Colors expected as hex strings (#RRGGBB) or 'rgb(r,g,b)'.
        Returns ratio in range [1.0, 21.0].
        """
        fg_rgb = self._parse_color(fg)
        bg_rgb = self._parse_color(bg)

        if fg_rgb is None or bg_rgb is None:
            return 21.0  # Assume pass if color cannot be parsed

        l1 = self._relative_luminance(fg_rgb)
        l2 = self._relative_luminance(bg_rgb)

        lighter = max(l1, l2)
        darker = min(l1, l2)

        return (lighter + 0.05) / (darker + 0.05)

    def _parse_color(self, color_str: str) -> Optional[Tuple[int, int, int]]:
        """Parses hex or rgb() color string into (R, G, B) tuple."""
        if not color_str:
            return None
        color_str = color_str.strip()

        # Hex format: #RRGGBB or #RGB
        if color_str.startswith("#"):
            hex_val = color_str[1:]
            if len(hex_val) == 3:
                hex_val = "".join(c * 2 for c in hex_val)
            if len(hex_val) == 6:
                try:
                    r = int(hex_val[0:2], 16)
                    g = int(hex_val[2:4], 16)
                    b = int(hex_val[4:6], 16)
                    return (r, g, b)
                except ValueError:
                    return None

        # rgb() format: rgb(255, 128, 0)
        if color_str.startswith("rgb"):
            try:
                parts = color_str.replace("rgb(", "").replace("rgba(", "").replace(")", "").split(",")
                r = int(parts[0].strip())
                g = int(parts[1].strip())
                b = int(parts[2].strip())
                return (r, g, b)
            except (ValueError, IndexError):
                return None

        return None

    def _relative_luminance(self, rgb: Tuple[int, int, int]) -> float:
        """Computes relative luminance per WCAG 2.1 §G18 formula."""
        def linearize(channel: int) -> float:
            srgb = channel / 255.0
            if srgb <= 0.03928:
                return srgb / 12.92
            return ((srgb + 0.055) / 1.055) ** 2.4

        r_lin = linearize(rgb[0])
        g_lin = linearize(rgb[1])
        b_lin = linearize(rgb[2])
        return 0.2126 * r_lin + 0.7152 * g_lin + 0.0722 * b_lin

    # ─── Focus & Tab Order Helpers ────────────────────────────────────────

    def _extract_focus_order(self, a11y_tree: Optional[Dict[str, Any]]) -> List[str]:
        """
        Extracts ordered list of focusable element names/roles from accessibility tree.
        Performs depth-first traversal to reflect DOM focus order.
        """
        if not a11y_tree:
            return []

        focus_order: List[str] = []

        def traverse(node: Dict[str, Any]):
            role = node.get("role", "")
            name = node.get("name", "")
            focusable = node.get("focused") is not None or role in ["button", "textbox", "link", "checkbox", "radio", "combobox", "menuitem"]

            if focusable and name:
                focus_order.append(name)

            for child in node.get("children", []):
                if isinstance(child, dict):
                    traverse(child)

        traverse(a11y_tree)
        return focus_order

    def _compare_focus_order(self, ref_order: List[str], act_order: List[str]) -> List[Dict[str, Any]]:
        """
        Compares reference and actual focus order sequences.
        Detects reordered, missing, or newly inserted focusable elements.
        """
        issues: List[Dict[str, Any]] = []

        # Detect missing focusable elements
        ref_set = set(ref_order)
        act_set = set(act_order)

        for name in ref_set - act_set:
            ref_pos = ref_order.index(name) + 1
            issues.append({
                "element": name,
                "ref_position": ref_pos,
                "act_position": None,
                "explanation": (
                    f"Focus order regression: Focusable element '{name}' "
                    f"(reference position #{ref_pos}) is no longer in the focus sequence."
                )
            })

        # Detect order changes for elements present in both
        common = [name for name in ref_order if name in act_set]
        act_positions = {name: i for i, name in enumerate(act_order)}

        for i in range(len(common)):
            for j in range(i + 1, len(common)):
                name_i = common[i]
                name_j = common[j]
                if act_positions.get(name_i, 0) > act_positions.get(name_j, 0):
                    issues.append({
                        "element": name_i,
                        "ref_position": ref_order.index(name_i) + 1,
                        "act_position": act_order.index(name_i) + 1,
                        "explanation": (
                            f"Focus order regression: '{name_i}' appears before '{name_j}' in reference "
                            f"but after it in actual render, breaking expected keyboard navigation sequence."
                        )
                    })
                    break  # Report first inversion per element

        return issues

    def _validate_tab_order(
        self,
        dom_nodes: List[Dict[str, Any]],
        ref_dom_map: Dict[str, Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Validates tab index sequence for interactive elements.
        Detects: duplicate positive tabindex values, gaps in tabindex sequences,
        positive tabindex values > 0 (anti-pattern), and tabindex regressions vs baseline.
        """
        issues: List[Dict[str, Any]] = []

        interactive_nodes = [
            n for n in dom_nodes
            if n.get("tag") in ["button", "input", "select", "a", "textarea"]
            or n.get("role") in ["button", "link", "textbox", "checkbox", "radio"]
        ]

        tabindex_values: Dict[int, List[str]] = {}
        for node in interactive_nodes:
            tab_idx = node.get("tabIndex")
            if tab_idx is not None and isinstance(tab_idx, int):
                node_id = node.get("id") or f"{node.get('tag')}_{node.get('text', '')[:15]}"

                # Anti-pattern: positive tabindex > 0
                if tab_idx > 0:
                    issues.append({
                        "element_id": node_id,
                        "severity": "MEDIUM",
                        "explanation": (
                            f"Tab order anti-pattern: <{node.get('tag')} id='{node_id}'> "
                            f"uses positive tabindex={tab_idx}. Positive tabindex values "
                            f"disrupt natural DOM focus order and should be avoided."
                        )
                    })

                # Detect duplicates
                if tab_idx not in tabindex_values:
                    tabindex_values[tab_idx] = []
                tabindex_values[tab_idx].append(node_id)

                # Detect tabindex regression vs baseline
                node_key = node.get("id") or f"{node.get('tag')}_{node.get('text', '')[:20]}"
                if node_key in ref_dom_map:
                    ref_tab_idx = ref_dom_map[node_key].get("tabIndex")
                    if ref_tab_idx is not None and ref_tab_idx != tab_idx:
                        issues.append({
                            "element_id": node_id,
                            "severity": "HIGH",
                            "explanation": (
                                f"Tab order regression: <{node.get('tag')} id='{node_id}'> "
                                f"tabindex changed from {ref_tab_idx} to {tab_idx} "
                                f"(baseline vs. actual), altering keyboard navigation flow."
                            )
                        })

        # Report duplicate positive tabindex values
        for idx_val, elements in tabindex_values.items():
            if idx_val > 0 and len(elements) > 1:
                issues.append({
                    "element_id": ", ".join(elements),
                    "severity": "MEDIUM",
                    "explanation": (
                        f"Duplicate tabindex={idx_val} found on elements: {', '.join(elements)}. "
                        f"Duplicate positive tabindex values cause unpredictable focus ordering."
                    )
                })

        return issues

    # ─── Reporting Helpers ────────────────────────────────────────────────

    def _summarize_defect_types(self, defects: List[Dict[str, Any]]) -> Dict[str, int]:
        """Returns count of each defect type for summary reporting."""
        summary: Dict[str, int] = {}
        for d in defects:
            dt = d.get("defect_type", "UNKNOWN")
            summary[dt] = summary.get(dt, 0) + 1
        return summary
