import os
import json
import time
import asyncio
from typing import Dict, Any, Optional
from playwright.async_api import async_playwright

DEVICE_CONFIGS = {
    "desktop_1920x1080": {"width": 1920, "height": 1080, "dpr": 1.0, "name": "Desktop 1080p"},
    "desktop_1366x768": {"width": 1366, "height": 768, "dpr": 1.0, "name": "Desktop Small"},
    "tablet_1024x768": {"width": 1024, "height": 768, "dpr": 2.0, "name": "Tablet Landscape"},
    "tablet_portrait_768x1024": {"width": 768, "height": 1024, "dpr": 2.0, "name": "Tablet Portrait"},
    "mobile_390x844": {"width": 390, "height": 844, "dpr": 3.0, "name": "Mobile iPhone 13"},
    "pos_kiosk_1280x720": {"width": 1280, "height": 720, "dpr": 1.5, "name": "POS Counter Kiosk"}
}

class PlaywrightRunner:
    def __init__(self, artifact_base_dir: str = "./artifacts", pos_url: str = "http://127.0.0.1:8000/pos-app/index.html"):
        self.artifact_base_dir = artifact_base_dir
        self.pos_url = pos_url
        os.makedirs(os.path.join(artifact_base_dir, "screenshots"), exist_ok=True)
        os.makedirs(os.path.join(artifact_base_dir, "accessibility"), exist_ok=True)
        os.makedirs(os.path.join(artifact_base_dir, "metadata"), exist_ok=True)

    async def capture_snapshot(
        self,
        screen: str,
        device_key: str,
        language: str = "en",
        accessibility_profile: str = "default",
        defect: Optional[str] = None,
        is_baseline: bool = False,
        version_tag: str = "v1"
    ) -> Dict[str, Any]:
        """
        Renders POS screen using Playwright and captures Screenshot + DOM Geometry + Accessibility Tree.
        Returns execution status & paths. Categorizes infrastructure timeouts as EXECUTION_FAILURE.
        """
        device = DEVICE_CONFIGS.get(device_key, DEVICE_CONFIGS["desktop_1920x1080"])
        
        # Build query string
        query_params = f"?screen={screen}&lang={language}&a11y={accessibility_profile}"
        if defect:
            query_params += f"&defect={defect}"

        full_url = f"{self.pos_url}{query_params}"

        filename_prefix = f"{screen}__{device_key}__{language}__{accessibility_profile}"
        if defect:
            filename_prefix += f"__defect_{defect}"
        if is_baseline:
            filename_prefix = f"baseline_{version_tag}__{filename_prefix}"

        screenshot_path = os.path.join(self.artifact_base_dir, "screenshots", f"{filename_prefix}.png")
        accessibility_path = os.path.join(self.artifact_base_dir, "accessibility", f"{filename_prefix}.json")
        metadata_path = os.path.join(self.artifact_base_dir, "metadata", f"{filename_prefix}.json")

        start_time = time.time()

        try:
            async with async_playwright() as p:
                try:
                    browser = await p.chromium.launch(headless=True)
                except Exception:
                    edge_path = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
                    if os.path.exists(edge_path):
                        browser = await p.chromium.launch(headless=True, executable_path=edge_path)
                    else:
                        browser = await p.chromium.launch(headless=True, channel="msedge")

                context = await browser.new_context(
                    viewport={"width": device["width"], "height": device["height"]},
                    device_scale_factor=device["dpr"],
                    locale="ar-SA" if language == "ar" else "en-US"
                )
                page = await context.new_page()

                # Navigate with domcontentloaded for high reliability
                response = await page.goto(full_url, wait_until="domcontentloaded", timeout=10000)

                # Allow dynamic DOM rendering script to complete
                await page.wait_for_timeout(300)

                # 1. Capture Screenshot
                await page.screenshot(path=screenshot_path, full_page=True)

                # 2. Extract DOM Geometry Bounding Boxes
                dom_geometry = await page.evaluate("""() => {
                    const elements = document.querySelectorAll('button, input, select, table, tr, .card, .summary-row, .product-card, h1, h2, h3, header, nav, main');
                    return Array.from(elements).map(el => {
                        const rect = el.getBoundingClientRect();
                        const styles = window.getComputedStyle(el);
                        return {
                            id: el.id || '',
                            tag: el.tagName.toLowerCase(),
                            role: el.getAttribute('role') || el.tagName.toLowerCase(),
                            text: el.innerText ? el.innerText.trim().substring(0, 100) : '',
                            ariaLabel: el.getAttribute('aria-label') || '',
                            focusable: el.tabIndex >= 0 || ['button', 'input', 'select', 'a'].includes(el.tagName.toLowerCase()),
                            bounds: {
                                x: Math.round(rect.x),
                                y: Math.round(rect.y),
                                width: Math.round(rect.width),
                                height: Math.round(rect.height)
                            },
                            visibility: styles.display !== 'none' && styles.visibility !== 'hidden' && rect.width > 0 && rect.height > 0
                        };
                    });
                }""")

                # 3. Extract Accessibility Snapshot / Tree
                accessibility_tree = await page.accessibility.snapshot()

                await browser.close()

                # Write metadata JSON files
                with open(accessibility_path, "w", encoding="utf-8") as f:
                    json.dump(accessibility_tree or {}, f, indent=2, ensure_ascii=False)

                with open(metadata_path, "w", encoding="utf-8") as f:
                    json.dump(dom_geometry, f, indent=2, ensure_ascii=False)

                return {
                    "status": "SUCCESS",
                    "screenshot_path": screenshot_path,
                    "accessibility_path": accessibility_path,
                    "metadata_path": metadata_path,
                    "execution_time_ms": (time.time() - start_time) * 1000,
                    "device": device,
                    "language": language,
                    "accessibility_profile": accessibility_profile,
                    "screen": screen,
                    "defect": defect
                }

        except Exception as ex:
            # RULE 6: Infrastructure failures must be classified as EXECUTION_FAILURE, NOT VISUAL_DEFECT!
            return {
                "status": "EXECUTION_FAILURE",
                "error": f"Playwright Runner Failure: {str(ex)}",
                "execution_time_ms": (time.time() - start_time) * 1000
            }
