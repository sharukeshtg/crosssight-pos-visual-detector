import os
import cv2
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim
from typing import Dict, Any, List, Tuple, Optional

class PixelVisualDetector:
    """
    Approach A: Pure Pixel & Perceptual (SSIM) Image Comparison Engine.
    Operates strictly on visual image data without DOM or accessibility tree inputs.
    """
    def __init__(self, visual_threshold: float = 0.95, diff_pct_threshold: float = 2.0):
        self.visual_threshold = visual_threshold # Minimum SSIM score to pass
        self.diff_pct_threshold = diff_pct_threshold # Max allowed pixel diff %

    def compare_screenshots(
        self,
        reference_image_path: str,
        actual_image_path: str,
        output_diff_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Compares reference screenshot against actual screenshot using OpenCV & SSIM.
        Generates difference heatmap and detects changed contours.
        """
        if not os.path.exists(reference_image_path):
            raise FileNotFoundError(f"Reference screenshot missing: {reference_image_path}")
        if not os.path.exists(actual_image_path):
            raise FileNotFoundError(f"Actual screenshot missing: {actual_image_path}")

        # Load images with OpenCV
        img_ref = cv2.imread(reference_image_path)
        img_act = cv2.imread(actual_image_path)

        if img_ref is None or img_act is None:
            raise ValueError("Failed to load reference or actual screenshot image.")

        # 1. Normalize dimensions if different
        h_ref, w_ref = img_ref.shape[:2]
        h_act, w_act = img_act.shape[:2]
        
        target_w = max(w_ref, w_act)
        target_h = max(h_ref, h_act)

        if (w_ref, h_ref) != (target_w, target_h):
            img_ref = cv2.resize(img_ref, (target_w, target_h), interpolation=cv2.INTER_AREA)
        if (w_act, h_act) != (target_w, target_h):
            img_act = cv2.resize(img_act, (target_w, target_h), interpolation=cv2.INTER_AREA)

        # Convert to Grayscale for SSIM
        gray_ref = cv2.cvtColor(img_ref, cv2.COLOR_BGR2GRAY)
        gray_act = cv2.cvtColor(img_act, cv2.COLOR_BGR2GRAY)

        # 2. Compute Structural Similarity Index (SSIM)
        score, diff_map = ssim(gray_ref, gray_act, full=True)
        diff_map = (diff_map * 255).astype("uint8")

        # 3. Compute Absolute Difference & Threshold
        abs_diff = cv2.absdiff(gray_ref, gray_act)
        _, thresh = cv2.threshold(abs_diff, 25, 255, cv2.THRESH_BINARY)

        # Calculate Pixel Difference Percentage
        total_pixels = target_w * target_h
        changed_pixels = np.count_nonzero(thresh)
        difference_percentage = (changed_pixels / total_pixels) * 100.0

        # 4. Find Changed Bounding Box Regions via Contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        changed_regions: List[Dict[str, int]] = []

        # Create Visual Diff Overlay Image
        diff_overlay = img_act.copy()

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 20: # Filter out anti-aliasing noise
                x, y, w, h = cv2.boundingRect(cnt)
                changed_regions.append({"x": int(x), "y": int(y), "w": int(w), "h": int(h)})
                # Draw red bounding boxes on diff image
                cv2.rectangle(diff_overlay, (x, y), (x + w, y + h), (0, 0, 255), 2)

        # Save diff image if path provided
        if output_diff_path:
            os.makedirs(os.path.dirname(output_diff_path), exist_ok=True)
            cv2.imwrite(output_diff_path, diff_overlay)

        # 5. Classify Result
        ssim_score = float(score)
        visual_score = ssim_score

        if visual_score >= self.visual_threshold and difference_percentage <= 0.5:
            classification = "PASS"
        elif visual_score >= 0.85 and difference_percentage <= self.diff_pct_threshold:
            classification = "WARNING"
        else:
            classification = "DEFECT_CANDIDATE"

        return {
            "visual_score": round(visual_score, 4),
            "ssim_score": round(ssim_score, 4),
            "difference_percentage": round(difference_percentage, 4),
            "changed_pixels": int(changed_pixels),
            "total_pixels": int(total_pixels),
            "changed_regions": changed_regions,
            "classification": classification,
            "diff_image_path": output_diff_path,
            "detector_mode": "PIXEL"
        }
