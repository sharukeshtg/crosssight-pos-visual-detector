from typing import Dict, Any, List


class LocalizationDetector:
    """
    Approach B Component: Localization & Internationalization (i18n / L10n) Analyzer.
    Handles German long-text translation expansion, Arabic RTL layout verification,
    language fallback detection, and dir attribute validation.

    Covers Defect Types:
    - TEXT_CUTOFF                (Text truncated without ellipsis by container bounds)
    - LOCALIZATION_OVERFLOW      (Translated string exceeds viewport bounds)
    - RTL_LAYOUT_ERROR           (Failure to mirror text/flex direction in RTL locales)
    - LANGUAGE_FALLBACK_ERROR    (Untranslated strings / source language leaking through)
    - DIRECTION_ATTRIBUTE_ERROR  (Missing or incorrect dir="rtl"/"ltr" on elements)
    """

    # RTL language codes that require dir="rtl" attribute
    RTL_LANGUAGES = {"ar", "he", "fa", "ur", "ps", "sd", "ku", "yi"}

    # Known English-only patterns used to detect fallback leaks
    ENGLISH_INDICATOR_WORDS = {
        "checkout", "add to cart", "submit", "continue", "pay now",
        "total", "subtotal", "shipping", "proceed", "cancel",
        "confirm", "order summary", "payment method", "search",
        "remove", "quantity", "price", "receipt"
    }

    # German expansion factor: German text typically 30-40% longer than English
    GERMAN_EXPANSION_TOLERANCE = 1.35

    def analyze_localization(
        self,
        language: str,
        dom_nodes: List[Dict[str, Any]],
        device_width: int,
        reference_nodes: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyzes localization defects across multiple dimensions:
        - Text overflow and cutoff detection
        - RTL layout alignment validation
        - Language fallback / untranslated string detection
        - HTML dir attribute correctness

        Parameters:
            language: ISO 639-1 code (e.g. 'en', 'de', 'ar', 'hi', 'ta')
            dom_nodes: DOM element metadata from actual render
            device_width: Viewport width in pixels
            reference_nodes: DOM element metadata from English reference (optional)
        """
        localization_defects: List[Dict[str, Any]] = []
        is_rtl = language in self.RTL_LANGUAGES

        # Build reference text map for fallback detection
        ref_text_map: Dict[str, str] = {}
        if reference_nodes:
            for node in reference_nodes:
                key = node.get("id") or f"{node.get('tag', '')}_{node.get('text', '')[:20]}"
                ref_text_map[key] = node.get("text", "")

        for node in dom_nodes:
            text = node.get("text", "")
            bounds = node.get("bounds", {"width": 0, "height": 0, "x": 0})
            id_val = node.get("id", "")
            tag = node.get("tag", "")
            node_key = id_val or f"{tag}_{text[:20]}"

            # ─── 1. Text Overflow / Cutoff Detection ──────────────────────
            if bounds["x"] + bounds["width"] > device_width + 10:
                if language == "de" and len(text) > 25:
                    severity = "HIGH"
                    defect_type = "LOCALIZATION_OVERFLOW"
                    explanation = (
                        f"German translation text '{text[:40]}...' caused element width "
                        f"({bounds['width']}px) to exceed viewport width ({device_width}px) "
                        f"by {bounds['x'] + bounds['width'] - device_width}px."
                    )
                else:
                    severity = "HIGH"
                    defect_type = "TEXT_CUTOFF"
                    explanation = (
                        f"Text content '{text[:40]}...' clipped/overflowed viewport boundaries "
                        f"(element right edge at {bounds['x'] + bounds['width']}px, "
                        f"viewport width: {device_width}px)."
                    )

                localization_defects.append({
                    "defect_type": defect_type,
                    "severity": severity,
                    "element_id": id_val,
                    "element_tag": tag,
                    "language": language,
                    "explanation": explanation
                })

            # ─── 2. Arabic / RTL Alignment Checks ─────────────────────────
            if is_rtl:
                text_align = node.get("textAlign", "")
                direction = node.get("direction", "")
                flex_direction = node.get("flexDirection", "")

                # Check text alignment (should be "right" or "start" in RTL)
                if text_align in ["left"] and tag in ["button", "th", "td", "h1", "h2", "h3", "p", "span", "label"]:
                    localization_defects.append({
                        "defect_type": "RTL_LAYOUT_ERROR",
                        "severity": "HIGH",
                        "element_id": id_val,
                        "element_tag": tag,
                        "language": language,
                        "measured_alignment": text_align,
                        "expected_alignment": "right",
                        "explanation": (
                            f"RTL directional layout failure: <{tag} id='{id_val}'> has "
                            f"text-align:{text_align} in {language} locale. "
                            f"Expected text-align:right for RTL content."
                        )
                    })

                # Check flex direction (should be "row-reverse" in RTL for horizontal layouts)
                if flex_direction == "row" and tag in ["nav", "header", "div"]:
                    if node.get("childCount", 0) > 1:
                        localization_defects.append({
                            "defect_type": "RTL_LAYOUT_ERROR",
                            "severity": "MEDIUM",
                            "element_id": id_val,
                            "element_tag": tag,
                            "language": language,
                            "explanation": (
                                f"RTL flex direction issue: <{tag} id='{id_val}'> uses "
                                f"flex-direction:row in {language} locale. Horizontal flex "
                                f"containers should use row-reverse for proper RTL ordering."
                            )
                        })



            # ─── 3. LANGUAGE_FALLBACK_ERROR ────────────────────────────────
            # Detect untranslated English strings leaking into non-English locales
            if language not in ["en", ""] and text and len(text) > 3:
                text_lower = text.lower().strip()

                # Method A: Exact match against known English UI patterns
                is_english_pattern = any(
                    eng_word in text_lower
                    for eng_word in self.ENGLISH_INDICATOR_WORDS
                )

                # Method B: Compare with reference English text
                # If text is identical to English reference, likely untranslated
                is_identical_to_ref = False
                if node_key in ref_text_map:
                    ref_text = ref_text_map[node_key]
                    if ref_text and text == ref_text and len(text) > 5:
                        is_identical_to_ref = True

                if is_english_pattern or is_identical_to_ref:
                    localization_defects.append({
                        "defect_type": "LANGUAGE_FALLBACK_ERROR",
                        "severity": "HIGH" if tag in ["button", "h1", "h2", "label"] else "MEDIUM",
                        "element_id": id_val,
                        "element_tag": tag,
                        "language": language,
                        "detected_text": text[:60],
                        "detection_method": "english_pattern_match" if is_english_pattern else "reference_identity",
                        "explanation": (
                            f"Language fallback detected: <{tag} id='{id_val}'> displays "
                            f"untranslated English text '{text[:40]}' in {language} locale. "
                            f"Translation key missing or locale bundle incomplete."
                        )
                    })

            # ─── 4. DIRECTION_ATTRIBUTE_ERROR ─────────────────────────────
            # Validate that HTML dir attribute matches language direction expectation
            dir_attr = node.get("dir", "")
            if is_rtl and dir_attr == "ltr":
                # RTL language but element explicitly set to LTR
                if tag in ["html", "body", "main", "section", "div", "form", "table"]:
                    localization_defects.append({
                        "defect_type": "DIRECTION_ATTRIBUTE_ERROR",
                        "severity": "CRITICAL" if tag in ["html", "body"] else "HIGH",
                        "element_id": id_val,
                        "element_tag": tag,
                        "language": language,
                        "actual_dir": dir_attr,
                        "expected_dir": "rtl",
                        "explanation": (
                            f"Direction attribute error: <{tag} id='{id_val}'> has dir='ltr' "
                            f"but language '{language}' requires dir='rtl'. "
                            f"{'Root element direction affects entire page layout.' if tag in ['html', 'body'] else ''}"
                        )
                    })

            if not is_rtl and dir_attr == "rtl":
                # LTR language but element explicitly set to RTL
                if tag in ["html", "body", "main", "section"]:
                    localization_defects.append({
                        "defect_type": "DIRECTION_ATTRIBUTE_ERROR",
                        "severity": "HIGH",
                        "element_id": id_val,
                        "element_tag": tag,
                        "language": language,
                        "actual_dir": dir_attr,
                        "expected_dir": "ltr",
                        "explanation": (
                            f"Direction attribute error: <{tag} id='{id_val}'> has dir='rtl' "
                            f"but language '{language}' is left-to-right. "
                            f"Incorrect dir attribute causes reversed text flow."
                        )
                    })

        # Score calculation: weighted by severity
        score_penalty = 0.0
        for d in localization_defects:
            sev = d.get("severity", "LOW")
            if sev == "CRITICAL":
                score_penalty += 0.30
            elif sev == "HIGH":
                score_penalty += 0.20
            elif sev == "MEDIUM":
                score_penalty += 0.10
            else:
                score_penalty += 0.05
        localization_score = max(0.0, 1.0 - score_penalty)

        return {
            "localization_score": round(localization_score, 4),
            "localization_defects": localization_defects,
            "language": language,
            "is_rtl": is_rtl,
            "total_nodes_analyzed": len(dom_nodes),
            "defect_type_summary": self._summarize_defect_types(localization_defects)
        }

    def _summarize_defect_types(self, defects: List[Dict[str, Any]]) -> Dict[str, int]:
        """Returns count of each defect type for summary reporting."""
        summary: Dict[str, int] = {}
        for d in defects:
            dt = d.get("defect_type", "UNKNOWN")
            summary[dt] = summary.get(dt, 0) + 1
        return summary
