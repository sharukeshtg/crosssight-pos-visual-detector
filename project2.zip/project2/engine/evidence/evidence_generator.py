import os
import json
import datetime
import cv2
from typing import Dict, Any, Optional

class EvidenceGenerator:
    """
    Evidence Generator for HIGH and CRITICAL POS Regressions.
    Produces comprehensive evidence packages containing side-by-side screenshots, visual heatmaps,
    bounding box highlight overlays, geometry diffs, accessibility diffs, and exact reproduction parameters.
    """

    def __init__(self, artifact_base_dir: str = "./artifacts"):
        self.artifact_base_dir = artifact_base_dir
        self.evidence_dir = os.path.join(artifact_base_dir, "evidence")
        os.makedirs(self.evidence_dir, exist_ok=True)

    def create_evidence_package(
        self,
        defect_code: str,
        reference_snapshot: Dict[str, Any],
        actual_snapshot: Dict[str, Any],
        detection_result: Dict[str, Any],
        baseline_version_tag: str = "baseline-v1"
    ) -> Dict[str, Any]:
        """
        Creates an evidence package for a detected defect.
        """
        ref_img_path = reference_snapshot.get("screenshot_path", "")
        act_img_path = actual_snapshot.get("screenshot_path", "")
        diff_img_path = detection_result.get("diff_image_path", "")

        highlight_path = os.path.join(self.evidence_dir, f"highlight__{defect_code}.png")

        # Generate Highlighted Region Overlay Image
        if os.path.exists(act_img_path):
            img = cv2.imread(act_img_path)
            if img is not None:
                # Highlight detected defect regions
                for d in detection_result.get("detected_defects", []):
                    # Draw warning box / banner overlay
                    cv2.putText(img, f"DEFECT: {d['defect_type']}", (20, 40),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
                cv2.imwrite(highlight_path, img)
        else:
            highlight_path = act_img_path

        reproduction_config = {
            "screen": actual_snapshot.get("screen"),
            "device_key": actual_snapshot.get("device_key"),
            "language": actual_snapshot.get("language"),
            "accessibility_profile": actual_snapshot.get("accessibility_profile"),
            "defect": actual_snapshot.get("defect"),
            "query_string": f"?screen={actual_snapshot.get('screen')}&lang={actual_snapshot.get('language')}&a11y={actual_snapshot.get('accessibility_profile')}" + (f"&defect={actual_snapshot.get('defect')}" if actual_snapshot.get("defect") else "")
        }

        evidence_package = {
            "defect_code": defect_code,
            "severity": detection_result.get("severity"),
            "classification": detection_result.get("classification"),
            "reference_screenshot_path": ref_img_path,
            "actual_screenshot_path": act_img_path,
            "diff_image_path": diff_img_path or act_img_path,
            "highlighted_region_path": highlight_path,
            "device": actual_snapshot.get("device"),
            "language": actual_snapshot.get("language"),
            "accessibility_profile": actual_snapshot.get("accessibility_profile"),
            "detector_scores": {
                "overall_regression_score": detection_result.get("overall_regression_score"),
                "visual_score": detection_result.get("visual_score"),
                "ssim_score": detection_result.get("ssim_score"),
                "geometry_score": detection_result.get("geometry_score"),
                "accessibility_score": detection_result.get("accessibility_score"),
                "localization_score": detection_result.get("localization_score")
            },
            "detector_version": detection_result.get("detector_version"),
            "threshold_version": detection_result.get("threshold_version"),
            "baseline_version": baseline_version_tag,
            "explanation": detection_result.get("explanation"),
            "detected_defects": detection_result.get("detected_defects", []),
            "reproduction_config": reproduction_config,
            "timestamp": datetime.datetime.utcnow().isoformat()
        }

        # Write evidence JSON manifest
        manifest_path = os.path.join(self.evidence_dir, f"manifest__{defect_code}.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(evidence_package, f, indent=2)

        return evidence_package
