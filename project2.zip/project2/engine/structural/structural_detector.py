import math
from typing import Dict, Any, List, Optional


class StructuralDetector:
    """
    Approach B Component: DOM Structural & Bounding-Box Geometry Analyzer.
    Analyzes DOM element positioning, layout relationships, bounding box overlaps,
    clipping, text wrapping, z-index stacking, scroll overflow, and missing elements.

    Covers Defect Types:
    - MISSING_ELEMENT
    - ELEMENT_ADDED_UNEXPECTEDLY
    - LAYOUT_SHIFT
    - WRAPPING_ERROR
    - OVERLAP
    - WRONG_POSITION
    - Z_INDEX_REGRESSION         (z-index stacking order changed from baseline)
    - CLIPPED_ELEMENT            (visible content clipped by container overflow)
    - HORIZONTAL_SCROLL          (unintended horizontal scroll introduced)
    - VERTICAL_SCROLL            (unintended vertical scroll beyond expected bounds)
    - IMAGE_ICON_MISSING         (image/icon src broken or element dimensions collapsed)
    """

    # Configurable anomaly thresholds
    POSITION_SHIFT_THRESHOLD_PX = 35       # dx or dy > 35px triggers LAYOUT_SHIFT
    SIZE_CHANGE_THRESHOLD_PX = 40          # dw or dh > 40px triggers size change
    WRAPPING_WIDTH_THRESHOLD_PX = 50       # width increase > 50px indicates wrapping
    OVERLAP_IOU_THRESHOLD = 0.20           # IoU > 20% of smaller element triggers OVERLAP
    WRONG_POSITION_THRESHOLD_PX = 50       # Position delta > 50px triggers WRONG_POSITION
    HORIZONTAL_SCROLL_TOLERANCE_PX = 10    # Element extends > viewport + 10px
    ICON_MIN_DIMENSION_PX = 4             # Image/icon collapsed below this = broken

    def compare_geometry(
        self,
        reference_nodes: List[Dict[str, Any]],
        actual_nodes: List[Dict[str, Any]],
        viewport_width: int = 1920,
        viewport_height: int = 1080
    ) -> Dict[str, Any]:
        """
        Compares reference DOM nodes against actual DOM nodes.
        Detects missing elements, unexpected elements, position shifts, size changes,
        bounding box collisions (overlaps), z-index regressions, clipped elements,
        scroll overflow violations, and missing images/icons.
        """
        defects_detected: List[Dict[str, Any]] = []

        ref_map = {
            n.get("id") or f"{n['tag']}_{n['text'][:20]}": n
            for n in reference_nodes if n.get("visibility")
        }
        act_map = {
            n.get("id") or f"{n['tag']}_{n['text'][:20]}": n
            for n in actual_nodes if n.get("visibility")
        }

        # 1. MISSING_ELEMENT: Reference element absent from actual
        for key, ref_el in ref_map.items():
            if key not in act_map:
                defects_detected.append({
                    "defect_type": "MISSING_ELEMENT",
                    "severity": "CRITICAL" if "btn" in key or "total" in key else "HIGH",
                    "element_id": ref_el.get("id", ""),
                    "element_tag": ref_el.get("tag", ""),
                    "explanation": f"Element '{key}' was present in reference but missing in actual view."
                })

        # 2. ELEMENT_ADDED_UNEXPECTEDLY: Actual element not in reference
        for key, act_el in act_map.items():
            if key not in ref_map:
                # Exclude known dynamic elements (e.g., injected scripts, devtools artifacts)
                tag = act_el.get("tag", "").lower()
                if tag not in ["script", "style", "link", "meta", "noscript"]:
                    defects_detected.append({
                        "defect_type": "ELEMENT_ADDED_UNEXPECTEDLY",
                        "severity": "MEDIUM",
                        "element_id": act_el.get("id", ""),
                        "element_tag": act_el.get("tag", ""),
                        "explanation": (
                            f"Element '{key}' (<{tag}>) appears in actual render but was "
                            f"absent from reference baseline. Unexpected DOM additions may indicate "
                            f"injected content, unintended feature flags, or regression side-effects."
                        )
                    })

        # 3. Position Shifts, Size Changes, and WRONG_POSITION
        for key, act_el in act_map.items():
            if key in ref_map:
                ref_el = ref_map[key]
                rb = ref_el["bounds"]
                ab = act_el["bounds"]

                dx = abs(rb["x"] - ab["x"])
                dy = abs(rb["y"] - ab["y"])
                dw = abs(rb["width"] - ab["width"])
                dh = abs(rb["height"] - ab["height"])

                # WRONG_POSITION (> 50px absolute displacement)
                if dx > self.WRONG_POSITION_THRESHOLD_PX or dy > self.WRONG_POSITION_THRESHOLD_PX:
                    defects_detected.append({
                        "defect_type": "WRONG_POSITION",
                        "severity": "HIGH",
                        "element_id": act_el.get("id", ""),
                        "element_tag": act_el.get("tag", ""),
                        "dx_px": dx,
                        "dy_px": dy,
                        "explanation": (
                            f"Element '{key}' displaced by dx={dx}px, dy={dy}px "
                            f"from reference position ({rb['x']},{rb['y']}) to ({ab['x']},{ab['y']}). "
                            f"Exceeds {self.WRONG_POSITION_THRESHOLD_PX}px threshold."
                        )
                    })
                # LAYOUT_SHIFT (> 35px displacement, less severe)
                elif dx > self.POSITION_SHIFT_THRESHOLD_PX or dy > self.POSITION_SHIFT_THRESHOLD_PX:
                    defects_detected.append({
                        "defect_type": "LAYOUT_SHIFT",
                        "severity": "HIGH",
                        "element_id": act_el.get("id", ""),
                        "element_tag": act_el.get("tag", ""),
                        "dx_px": dx,
                        "dy_px": dy,
                        "explanation": (
                            f"Element '{key}' moved by dx={dx}px, dy={dy}px from reference "
                            f"position ({rb['x']},{rb['y']}) to ({ab['x']},{ab['y']})."
                        )
                    })

                # Size Change (> 40px)
                if dw > self.SIZE_CHANGE_THRESHOLD_PX or dh > self.SIZE_CHANGE_THRESHOLD_PX:
                    defects_detected.append({
                        "defect_type": "WRAPPING_ERROR" if dw > self.WRAPPING_WIDTH_THRESHOLD_PX else "LAYOUT_SHIFT",
                        "severity": "MEDIUM",
                        "element_id": act_el.get("id", ""),
                        "element_tag": act_el.get("tag", ""),
                        "explanation": (
                            f"Element '{key}' changed dimensions from "
                            f"{rb['width']}x{rb['height']} to {ab['width']}x{ab['height']}."
                        )
                    })

        # 4. Bounding Box Overlap / Collision Detection
        act_elements = list(act_map.values())
        for i in range(len(act_elements)):
            for j in range(i + 1, len(act_elements)):
                el1 = act_elements[i]
                el2 = act_elements[j]

                # Ignore nested containment ONLY if one is a recognized container element
                if self._is_container_containment(el1, el2):
                    continue

                overlap_ratio = self._check_overlap_ratio(el1["bounds"], el2["bounds"])
                if overlap_ratio > self.OVERLAP_IOU_THRESHOLD:
                    defects_detected.append({
                        "defect_type": "OVERLAP",
                        "severity": "CRITICAL" if "btn" in el1.get("id", "") or "btn" in el2.get("id", "") else "HIGH",
                        "element_id": f"{el1.get('id', '')} & {el2.get('id', '')}",
                        "overlap_ratio": round(overlap_ratio, 4),
                        "explanation": (
                            f"Element '{el1.get('id') or el1['tag']}' visually overlaps "
                            f"'{el2.get('id') or el2['tag']}' (overlap ratio: {overlap_ratio:.2%} "
                            f"> {self.OVERLAP_IOU_THRESHOLD:.0%} threshold)."
                        )
                    })

        # 5. Z_INDEX_REGRESSION: Stacking order changed between reference and actual
        for key, act_el in act_map.items():
            if key in ref_map:
                ref_el = ref_map[key]
                ref_z = ref_el.get("zIndex")
                act_z = act_el.get("zIndex")

                if ref_z is not None and act_z is not None:
                    try:
                        ref_z_val = int(ref_z) if ref_z != "auto" else 0
                        act_z_val = int(act_z) if act_z != "auto" else 0
                        if ref_z_val != act_z_val:
                            defects_detected.append({
                                "defect_type": "Z_INDEX_REGRESSION",
                                "severity": "MEDIUM",
                                "element_id": act_el.get("id", ""),
                                "element_tag": act_el.get("tag", ""),
                                "reference_zIndex": ref_z,
                                "actual_zIndex": act_z,
                                "explanation": (
                                    f"Z-index stacking order changed on '{key}': "
                                    f"reference z-index={ref_z}, actual z-index={act_z}. "
                                    f"May cause overlapping or hidden interactive elements."
                                )
                            })
                    except (ValueError, TypeError):
                        pass

        # 6. CLIPPED_ELEMENT: Visible content clipped by parent overflow
        for key, act_el in act_map.items():
            overflow = act_el.get("overflow", "visible")
            if overflow in ["hidden", "clip"]:
                bounds = act_el["bounds"]
                scroll_w = act_el.get("scrollWidth", bounds["width"])
                scroll_h = act_el.get("scrollHeight", bounds["height"])

                if scroll_w > bounds["width"] + 5 or scroll_h > bounds["height"] + 5:
                    defects_detected.append({
                        "defect_type": "CLIPPED_ELEMENT",
                        "severity": "HIGH",
                        "element_id": act_el.get("id", ""),
                        "element_tag": act_el.get("tag", ""),
                        "visible_size": f"{bounds['width']}x{bounds['height']}",
                        "content_size": f"{scroll_w}x{scroll_h}",
                        "explanation": (
                            f"Element '{key}' has overflow:{overflow} but content "
                            f"({scroll_w}x{scroll_h}px) exceeds visible bounds "
                            f"({bounds['width']}x{bounds['height']}px). "
                            f"Content is being clipped and may hide critical information."
                        )
                    })

        # 7. HORIZONTAL_SCROLL: Element extends beyond viewport width
        for key, act_el in act_map.items():
            bounds = act_el["bounds"]
            right_edge = bounds["x"] + bounds["width"]
            if right_edge > viewport_width + self.HORIZONTAL_SCROLL_TOLERANCE_PX:
                defects_detected.append({
                    "defect_type": "HORIZONTAL_SCROLL",
                    "severity": "HIGH",
                    "element_id": act_el.get("id", ""),
                    "element_tag": act_el.get("tag", ""),
                    "element_right_edge": right_edge,
                    "viewport_width": viewport_width,
                    "overshoot_px": right_edge - viewport_width,
                    "explanation": (
                        f"Element '{key}' extends to x={right_edge}px, "
                        f"exceeding viewport width ({viewport_width}px) by "
                        f"{right_edge - viewport_width}px. Causes unintended horizontal scrollbar."
                    )
                })

        # 8. VERTICAL_SCROLL: Content extends far beyond expected viewport height
        # Only flag if actual has significantly more vertical content than reference
        max_ref_bottom = 0
        for ref_el in ref_map.values():
            rb = ref_el["bounds"]
            bottom = rb["y"] + rb["height"]
            if bottom > max_ref_bottom:
                max_ref_bottom = bottom

        max_act_bottom = 0
        worst_vertical_el = None
        for act_el in act_map.values():
            ab = act_el["bounds"]
            bottom = ab["y"] + ab["height"]
            if bottom > max_act_bottom:
                max_act_bottom = bottom
                worst_vertical_el = act_el

        vertical_growth = max_act_bottom - max_ref_bottom
        if max_ref_bottom > 0 and vertical_growth > viewport_height * 0.5:
            defects_detected.append({
                "defect_type": "VERTICAL_SCROLL",
                "severity": "MEDIUM",
                "element_id": worst_vertical_el.get("id", "") if worst_vertical_el else "",
                "reference_max_y": max_ref_bottom,
                "actual_max_y": max_act_bottom,
                "growth_px": vertical_growth,
                "explanation": (
                    f"Page content height grew by {vertical_growth}px "
                    f"(reference: {max_ref_bottom}px, actual: {max_act_bottom}px), "
                    f"exceeding 50% of viewport height ({viewport_height}px). "
                    f"May indicate layout breakage or unwanted content injection."
                )
            })

        # 9. IMAGE_ICON_MISSING: Images/icons with broken src or collapsed dimensions
        for key, act_el in act_map.items():
            tag = act_el.get("tag", "").lower()
            if tag in ["img", "svg", "picture", "icon"]:
                bounds = act_el["bounds"]
                if bounds["width"] < self.ICON_MIN_DIMENSION_PX or bounds["height"] < self.ICON_MIN_DIMENSION_PX:
                    defects_detected.append({
                        "defect_type": "IMAGE_ICON_MISSING",
                        "severity": "HIGH",
                        "element_id": act_el.get("id", ""),
                        "element_tag": tag,
                        "rendered_size": f"{bounds['width']}x{bounds['height']}",
                        "explanation": (
                            f"Image/icon element '{key}' has collapsed dimensions "
                            f"({bounds['width']}x{bounds['height']}px < {self.ICON_MIN_DIMENSION_PX}px minimum). "
                            f"Likely broken image source or CSS loading failure."
                        )
                    })

            # Also check elements that reference background images
            if act_el.get("hasBackgroundImage") and act_el.get("backgroundImageLoaded") is False:
                defects_detected.append({
                    "defect_type": "IMAGE_ICON_MISSING",
                    "severity": "MEDIUM",
                    "element_id": act_el.get("id", ""),
                    "element_tag": tag,
                    "explanation": (
                        f"Element '{key}' has a CSS background-image that failed to load. "
                        f"Missing visual asset may affect user experience."
                    )
                })

        # Geometry score calculation
        # Weighted by severity: CRITICAL=0.25, HIGH=0.15, MEDIUM=0.08, LOW=0.04
        score_penalty = 0.0
        for d in defects_detected:
            sev = d.get("severity", "LOW")
            if sev == "CRITICAL":
                score_penalty += 0.25
            elif sev == "HIGH":
                score_penalty += 0.15
            elif sev == "MEDIUM":
                score_penalty += 0.08
            else:
                score_penalty += 0.04
        geometry_score = max(0.0, 1.0 - score_penalty)

        return {
            "geometry_score": round(geometry_score, 4),
            "structural_defects": defects_detected,
            "ref_element_count": len(ref_map),
            "act_element_count": len(act_map),
            "viewport": {"width": viewport_width, "height": viewport_height},
            "defect_type_summary": self._summarize_defect_types(defects_detected),
            "thresholds_used": {
                "position_shift_px": self.POSITION_SHIFT_THRESHOLD_PX,
                "wrong_position_px": self.WRONG_POSITION_THRESHOLD_PX,
                "size_change_px": self.SIZE_CHANGE_THRESHOLD_PX,
                "overlap_iou": self.OVERLAP_IOU_THRESHOLD,
                "horizontal_scroll_tolerance_px": self.HORIZONTAL_SCROLL_TOLERANCE_PX,
                "icon_min_dimension_px": self.ICON_MIN_DIMENSION_PX
            }
        }

    def _check_overlap_ratio(self, b1: Dict[str, int], b2: Dict[str, int]) -> float:
        """Returns overlap ratio (intersection area / smaller element area)."""
        x_left = max(b1["x"], b2["x"])
        y_top = max(b1["y"], b2["y"])
        x_right = min(b1["x"] + b1["width"], b2["x"] + b2["width"])
        y_bottom = min(b1["y"] + b1["height"], b2["y"] + b2["height"])

        if x_right > x_left and y_bottom > y_top:
            intersection_area = (x_right - x_left) * (y_bottom - y_top)
            min_area = min(b1["width"] * b1["height"], b2["width"] * b2["height"])
            return intersection_area / max(1, min_area)
        return 0.0

    # Keep backward-compatible method name
    def _check_overlap(self, b1: Dict[str, int], b2: Dict[str, int]) -> bool:
        """Returns True if bounding box b1 intersects b2 with significant area."""
        return self._check_overlap_ratio(b1, b2) > self.OVERLAP_IOU_THRESHOLD

    def _is_container_containment(self, el1: Dict[str, Any], el2: Dict[str, Any]) -> bool:
        """Returns True if containment is legitimate parent-child container hierarchy."""
        container_tags = {"card", "main", "nav", "header", "table", "form", "section", "div"}
        tag1 = el1.get("tag", "").lower()
        tag2 = el2.get("tag", "").lower()

        # If neither is a container element (e.g. button and span/text), overlap is invalid!
        if tag1 not in container_tags and tag2 not in container_tags:
            return False

        b1, b2 = el1["bounds"], el2["bounds"]
        b1_in_b2 = (b1["x"] >= b2["x"] and b1["y"] >= b2["y"] and
                    b1["x"] + b1["width"] <= b2["x"] + b2["width"] and
                    b1["y"] + b1["height"] <= b2["y"] + b2["height"])
        b2_in_b1 = (b2["x"] >= b1["x"] and b2["y"] >= b1["y"] and
                    b2["x"] + b2["width"] <= b1["x"] + b1["width"] and
                    b2["y"] + b2["height"] <= b1["y"] + b1["height"])

        return (b1_in_b2 and tag2 in container_tags) or (b2_in_b1 and tag1 in container_tags)

    def _summarize_defect_types(self, defects: List[Dict[str, Any]]) -> Dict[str, int]:
        """Returns count of each defect type for summary reporting."""
        summary: Dict[str, int] = {}
        for d in defects:
            dt = d.get("defect_type", "UNKNOWN")
            summary[dt] = summary.get(dt, 0) + 1
        return summary
