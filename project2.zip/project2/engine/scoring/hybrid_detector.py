import os
import json
import datetime
from typing import Dict, Any, List, Optional
from engine.visual.pixel_detector import PixelVisualDetector
from engine.structural.structural_detector import StructuralDetector
from engine.accessibility.accessibility_detector import AccessibilityDetector
from engine.localization.localization_detector import LocalizationDetector


class HybridDetector:
    """
    Approach B: Integrated Hybrid Detector.
    Combines Visual (SSIM/pixel), Geometry/Structural, Accessibility, and Localization
    analysis into an explainable regression score.

    Produces comprehensive classification with:
    - Per-component sub-scores
    - Weighted aggregate regression score
    - Full defect taxonomy coverage (12+ defect types)
    - Severity-based triage
    - Threshold versioning and reproducibility metadata
    """

    DETECTOR_VERSION = "detector-v3-hybrid"
    THRESHOLD_VERSION = "threshold-v2.0"

    # Complete Defect Taxonomy (all 12+ supported defect types)
    DEFECT_TAXONOMY = {
        # Structural Defects
        "OVERLAP":                    {"engine": "Structural",     "severity_default": "CRITICAL", "formula": "IoU > 0.20"},
        "MISSING_ELEMENT":            {"engine": "Structural",     "severity_default": "CRITICAL", "formula": "Node in Ref AND Node not in Act"},
        "ELEMENT_ADDED_UNEXPECTEDLY": {"engine": "Structural",     "severity_default": "MEDIUM",   "formula": "Node in Act AND Node not in Ref"},
        "LAYOUT_SHIFT":               {"engine": "Structural",     "severity_default": "HIGH",     "formula": "dx > 35px OR dy > 35px"},
        "WRONG_POSITION":             {"engine": "Structural",     "severity_default": "HIGH",     "formula": "Position Shift > 50px"},
        "WRAPPING_ERROR":             {"engine": "Structural",     "severity_default": "MEDIUM",   "formula": "dw > 50px"},
        "Z_INDEX_REGRESSION":         {"engine": "Structural",     "severity_default": "MEDIUM",   "formula": "z-index(ref) != z-index(act)"},
        "CLIPPED_ELEMENT":            {"engine": "Structural",     "severity_default": "HIGH",     "formula": "scrollW > visibleW AND overflow:hidden"},
        "HORIZONTAL_SCROLL":          {"engine": "Structural",     "severity_default": "HIGH",     "formula": "x + w > viewport_w + 10px"},
        "VERTICAL_SCROLL":            {"engine": "Structural",     "severity_default": "MEDIUM",   "formula": "content_h > ref_h + 50% viewport"},
        "IMAGE_ICON_MISSING":         {"engine": "Structural",     "severity_default": "HIGH",     "formula": "img w < 4px OR h < 4px"},
        # Accessibility Defects
        "ACCESSIBLE_NAME_MISSING":    {"engine": "Accessibility",  "severity_default": "HIGH",     "formula": "Tag in [btn,input,a] AND len(name)==0"},
        "ROLE_MISMATCH":              {"engine": "Accessibility",  "severity_default": "HIGH",     "formula": "Tag==button AND Role not in [button,link]"},
        "CONTROL_TOO_SMALL":          {"engine": "Accessibility",  "severity_default": "MEDIUM",   "formula": "Width < 44px OR Height < 44px"},
        "KEYBOARD_ACCESSIBILITY_FAILURE": {"engine": "Accessibility", "severity_default": "CRITICAL", "formula": "Interactive AND not focusable"},
        "COLOR_CONTRAST_ERROR":       {"engine": "Accessibility",  "severity_default": "HIGH",     "formula": "Contrast Ratio < 4.5:1 (normal) / 3.0:1 (large)"},
        "FONT_SIZE_REGRESSION":       {"engine": "Accessibility",  "severity_default": "MEDIUM",   "formula": "abs(act-ref)/ref > 0.20"},
        "FOCUS_ORDER_REGRESSION":     {"engine": "Accessibility",  "severity_default": "HIGH",     "formula": "Focus sequence order changed from baseline"},
        "TAB_ORDER_REGRESSION":       {"engine": "Accessibility",  "severity_default": "HIGH",     "formula": "tabindex changed or duplicated"},
        # Localization Defects
        "TEXT_CUTOFF":                {"engine": "Localization",   "severity_default": "HIGH",     "formula": "Bounds Overflow"},
        "LOCALIZATION_OVERFLOW":      {"engine": "Localization",   "severity_default": "HIGH",     "formula": "x + w > W_viewport + 10px (l10n)"},
        "RTL_LAYOUT_ERROR":           {"engine": "Localization",   "severity_default": "HIGH",     "formula": "Lang in RTL AND Align == left"},
        "LANGUAGE_FALLBACK_ERROR":    {"engine": "Localization",   "severity_default": "HIGH",     "formula": "Non-EN locale AND text == EN reference"},
        "DIRECTION_ATTRIBUTE_ERROR":  {"engine": "Localization",   "severity_default": "HIGH",     "formula": "dir attr contradicts language direction"},
        # Visual Defects (pixel-only)
        "VISUAL_MISMATCH":            {"engine": "Visual",         "severity_default": "HIGH",     "formula": "SSIM < 0.95 AND diff% > 2.0"},
    }

    def __init__(
        self,
        visual_weight: float = 0.25,
        geometry_weight: float = 0.25,
        a11y_weight: float = 0.25,
        loc_weight: float = 0.25
    ):
        self.visual_weight = visual_weight
        self.geometry_weight = geometry_weight
        self.a11y_weight = a11y_weight
        self.loc_weight = loc_weight

        self.pixel_detector = PixelVisualDetector()
        self.structural_detector = StructuralDetector()
        self.accessibility_detector = AccessibilityDetector()
        self.localization_detector = LocalizationDetector()

    def run_hybrid_detection(
        self,
        reference_snapshot: Dict[str, Any],
        actual_snapshot: Dict[str, Any],
        output_diff_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Runs comprehensive Approach B hybrid detection pipeline.
        Orchestrates all four detection engines and merges results.
        """
        ref_img = reference_snapshot["screenshot_path"]
        act_img = actual_snapshot["screenshot_path"]

        ref_meta = self._load_json(reference_snapshot.get("metadata_path")) or []
        act_meta = self._load_json(actual_snapshot.get("metadata_path")) or []
        ref_a11y = self._load_json(reference_snapshot.get("accessibility_path")) or {}
        act_a11y = self._load_json(actual_snapshot.get("accessibility_path")) or {}

        lang = actual_snapshot.get("language", "en")
        device = actual_snapshot.get("device", {})
        device_width = device.get("width", 1920)
        device_height = device.get("height", 1080)

        # 1. Visual Component
        visual_res = self.pixel_detector.compare_screenshots(ref_img, act_img, output_diff_path)
        visual_score = visual_res["visual_score"]

        # 2. Structural & Geometry Component (with viewport info)
        struct_res = self.structural_detector.compare_geometry(
            ref_meta, act_meta,
            viewport_width=device_width,
            viewport_height=device_height
        )
        geometry_score = struct_res["geometry_score"]

        # 3. Accessibility Component (with reference DOM for regression comparison)
        a11y_res = self.accessibility_detector.compare_accessibility_tree(
            ref_a11y, act_a11y, act_meta,
            reference_dom_nodes=ref_meta
        )
        accessibility_score = a11y_res["accessibility_score"]

        # 4. Localization Component (with reference nodes for fallback detection)
        loc_res = self.localization_detector.analyze_localization(
            lang, act_meta, device_width,
            reference_nodes=ref_meta
        )
        localization_score = loc_res["localization_score"]

        # 5. Weighted Aggregate Regression Score (1.0 = perfect match, 0.0 = severe regression)
        overall_score = (
            (visual_score * self.visual_weight) +
            (geometry_score * self.geometry_weight) +
            (accessibility_score * self.a11y_weight) +
            (localization_score * self.loc_weight)
        )
        overall_score = round(overall_score, 4)

        # Collect all detected defects across engines
        all_defects = (
            struct_res["structural_defects"] +
            a11y_res["accessibility_defects"] +
            loc_res["localization_defects"]
        )

        # 6. Defect Classification & Severity
        if not all_defects and overall_score >= 0.95:
            classification = "ACCEPTABLE_VARIATION" if overall_score < 1.0 else "PASS"
            severity = "NONE"
            primary_defect_type = "NONE"
            explanation = "No visual or structural regressions detected across configuration."
        else:
            classification = "TRUE_DEFECT"

            # Determine highest severity
            severities = [d["severity"] for d in all_defects]
            if "CRITICAL" in severities:
                severity = "CRITICAL"
            elif "HIGH" in severities:
                severity = "HIGH"
            elif "MEDIUM" in severities:
                severity = "MEDIUM"
            else:
                severity = "LOW"

            primary_defect_type = all_defects[0]["defect_type"] if all_defects else "VISUAL_MISMATCH"

            # Build explainability summary
            defect_explanations = [d["explanation"] for d in all_defects]
            explanation = (
                f"Regression Detected [{severity}]: {primary_defect_type}. "
                f"Overall Score: {overall_score} (Visual: {visual_score}, Geometry: {geometry_score}, "
                f"A11y: {accessibility_score}, L10n: {localization_score}). "
                f"Details: {' | '.join(defect_explanations[:3])}"
            )

        # Build defect type summary across all engines
        combined_type_summary = {}
        for summary in [
            struct_res.get("defect_type_summary", {}),
            a11y_res.get("defect_type_summary", {}),
            loc_res.get("defect_type_summary", {})
        ]:
            for dt, count in summary.items():
                combined_type_summary[dt] = combined_type_summary.get(dt, 0) + count

        return {
            "detector_mode": "HYBRID",
            "detector_version": self.DETECTOR_VERSION,
            "threshold_version": self.THRESHOLD_VERSION,
            "overall_regression_score": overall_score,
            "visual_score": visual_score,
            "ssim_score": visual_res["ssim_score"],
            "geometry_score": geometry_score,
            "accessibility_score": accessibility_score,
            "localization_score": localization_score,
            "difference_percentage": visual_res["difference_percentage"],
            "classification": classification,
            "severity": severity,
            "primary_defect_type": primary_defect_type,
            "explanation": explanation,
            "detected_defects": all_defects,
            "defect_count": len(all_defects),
            "defect_type_summary": combined_type_summary,
            "diff_image_path": visual_res.get("diff_image_path"),
            "component_weights": {
                "visual": self.visual_weight,
                "geometry": self.geometry_weight,
                "accessibility": self.a11y_weight,
                "localization": self.loc_weight
            },
            "engine_metadata": {
                "structural": {
                    "ref_element_count": struct_res.get("ref_element_count"),
                    "act_element_count": struct_res.get("act_element_count"),
                    "thresholds_used": struct_res.get("thresholds_used", {})
                },
                "accessibility": {
                    "total_nodes_audited": a11y_res.get("total_nodes_audited"),
                    "focus_order_ref_count": a11y_res.get("focus_order_ref_count"),
                    "focus_order_act_count": a11y_res.get("focus_order_act_count")
                },
                "localization": {
                    "language": lang,
                    "is_rtl": loc_res.get("is_rtl", False),
                    "total_nodes_analyzed": loc_res.get("total_nodes_analyzed")
                },
                "visual": {
                    "changed_pixels": visual_res.get("changed_pixels"),
                    "total_pixels": visual_res.get("total_pixels"),
                    "changed_regions": len(visual_res.get("changed_regions", []))
                }
            },
            "detection_timestamp": datetime.datetime.utcnow().isoformat()
        }

    def get_defect_taxonomy(self) -> Dict[str, Any]:
        """Returns the complete defect taxonomy with thresholds and severity mappings."""
        return self.DEFECT_TAXONOMY

    def _load_json(self, path: Optional[str]) -> Any:
        if not path or not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
