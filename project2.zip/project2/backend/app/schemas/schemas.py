from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime

# User Schemas
class UserBase(BaseModel):
    username: str
    email: str
    role: str = "REVIEWER"

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    class Config:
        from_attributes = True

# Project Schemas
class ProjectBase(BaseModel):
    name: str
    description: Optional[str] = None
    version: str = "1.0.0"

class ProjectCreate(ProjectBase):
    pass

class ProjectResponse(ProjectBase):
    id: int
    created_at: datetime
    class Config:
        from_attributes = True

# Screen Schemas
class ScreenBase(BaseModel):
    name: str
    screen_key: str
    route_path: str
    description: Optional[str] = None

class ScreenResponse(ScreenBase):
    id: int
    project_id: int
    class Config:
        from_attributes = True

# Device Schemas
class DeviceBase(BaseModel):
    name: str
    device_key: str
    width: int
    height: int
    dpr: float = 1.0
    browser: str = "chromium"

class DeviceResponse(DeviceBase):
    id: int
    class Config:
        from_attributes = True

# Language Schemas
class LanguageResponse(BaseModel):
    id: int
    code: str
    name: str
    is_rtl: bool
    class Config:
        from_attributes = True

# Accessibility Profile Schemas
class AccessibilityProfileResponse(BaseModel):
    id: int
    key: str
    name: str
    description: Optional[str] = None
    class Config:
        from_attributes = True

# Baseline Schemas
class BaselineCreate(BaseModel):
    project_id: int
    screen_key: str
    device_key: str
    language_code: str
    accessibility_key: str

class BaselineResponse(BaseModel):
    id: int
    project_id: int
    screen_key: str
    device_key: str
    language_code: str
    accessibility_key: str
    active_version: str
    status: str
    created_at: datetime
    class Config:
        from_attributes = True

# Test Run Schemas
class TestRunCreate(BaseModel):
    project_id: int
    run_type: str = "REGRESSION"
    detector_mode: str = "HYBRID" # PIXEL vs HYBRID
    screen_key: Optional[str] = None
    device_key: Optional[str] = None
    language_code: Optional[str] = None
    accessibility_key: Optional[str] = None

class TestRunResponse(BaseModel):
    id: int
    project_id: int
    run_type: str
    detector_mode: str
    status: str
    error_message: Optional[str] = None
    total_scenarios: int
    passed_count: int
    warning_count: int
    defect_count: int
    execution_time_ms: float
    created_at: datetime
    class Config:
        from_attributes = True

# Defect & Evidence Schemas
class EvidenceResponse(BaseModel):
    id: int
    defect_id: int
    reference_screenshot_path: str
    actual_screenshot_path: str
    diff_image_path: str
    highlighted_region_path: str
    geometry_evidence: Optional[Dict[str, Any]] = None
    accessibility_diff: Optional[Dict[str, Any]] = None
    detector_metadata: Optional[Dict[str, Any]] = None
    created_at: datetime
    class Config:
        from_attributes = True

class DefectReviewRequest(BaseModel):
    reviewer_name: str
    action: str # APPROVED, REJECTED, EXPECTED, REOPENED
    notes: Optional[str] = None

class DefectResponse(BaseModel):
    id: int
    defect_code: str
    actual_snapshot_id: int
    baseline_version_tag: str
    detector_mode: str
    defect_type: str
    severity: str
    classification: str
    review_status: str
    overall_regression_score: float
    visual_score: float
    ssim_score: float
    geometry_score: float
    accessibility_score: float
    localization_score: float
    explanation: str
    reproduction_config: Optional[Dict[str, Any]] = None
    created_at: datetime
    evidence: Optional[EvidenceResponse] = None
    class Config:
        from_attributes = True

# Audit Log Schema
class AuditLogResponse(BaseModel):
    id: int
    user: str
    action: str
    entity_type: str
    entity_id: str
    previous_value: Optional[str] = None
    new_value: Optional[str] = None
    reason: Optional[str] = None
    timestamp: datetime
    class Config:
        from_attributes = True

# Rollback Request Schema
class RollbackRequest(BaseModel):
    baseline_id: int
    target_version_tag: str
    user: str
    reason: str
