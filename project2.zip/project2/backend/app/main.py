import os
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from backend.app.core.config import settings
from backend.app.core.database import get_db, engine, Base
from backend.app.models.models import (
    Project, Screen, Device, Language, AccessibilityProfile,
    Baseline, TestRun, Defect, Evidence, AuditLog, BaselineVersion
)
from backend.app.schemas.schemas import (
    ProjectCreate, ProjectResponse, ScreenResponse, DeviceResponse,
    LanguageResponse, AccessibilityProfileResponse, BaselineResponse,
    TestRunCreate, TestRunResponse, DefectResponse, EvidenceResponse,
    DefectReviewRequest, AuditLogResponse, RollbackRequest
)
from backend.app.services.services import PlatformService
from experiments.run_experiments import run_comparative_experiment

# Initialize DB Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url="/api/openapi.json"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Synthetic POS Application
pos_dir = os.path.abspath("./pos-app")
if os.path.exists(pos_dir):
    app.mount("/pos-app", StaticFiles(directory=pos_dir, html=True), name="pos-app")

# Mount Artifacts Storage
artifact_dir = os.path.abspath(settings.ARTIFACT_DIR)
os.makedirs(artifact_dir, exist_ok=True)
app.mount("/artifacts", StaticFiles(directory=artifact_dir), name="artifacts")

# Startup Seed Master Data
@app.on_event("startup")
def startup_event():
    db = next(get_db())
    service = PlatformService(db)
    service.seed_master_data()

# 1. Health Check
@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": settings.PROJECT_NAME, "version": settings.VERSION}

# 2. Projects
@app.get("/api/projects", response_model=List[ProjectResponse])
def get_projects(db: Session = Depends(get_db)):
    return db.query(Project).all()

@app.post("/api/projects", response_model=ProjectResponse)
def create_project(req: ProjectCreate, db: Session = Depends(get_db)):
    proj = Project(name=req.name, description=req.description, version=req.version)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return proj

# 3. Screens
@app.get("/api/screens", response_model=List[ScreenResponse])
def get_screens(db: Session = Depends(get_db)):
    return db.query(Screen).all()

# 4. Devices
@app.get("/api/devices", response_model=List[DeviceResponse])
def get_devices(db: Session = Depends(get_db)):
    return db.query(Device).all()

# 5. Languages
@app.get("/api/languages", response_model=List[LanguageResponse])
def get_languages(db: Session = Depends(get_db)):
    return db.query(Language).all()

# 6. Accessibility Profiles
@app.get("/api/accessibility-profiles", response_model=List[AccessibilityProfileResponse])
def get_accessibility_profiles(db: Session = Depends(get_db)):
    return db.query(AccessibilityProfile).all()

# 7. Baselines & Rollback
@app.get("/api/baselines", response_model=List[BaselineResponse])
def get_baselines(db: Session = Depends(get_db)):
    return db.query(Baseline).all()

@app.post("/api/baselines")
async def create_baseline(
    project_id: int = Query(...),
    screen_key: str = Query(...),
    device_key: str = Query(...),
    language_code: str = Query("en"),
    accessibility_key: str = Query("default"),
    db: Session = Depends(get_db)
):
    service = PlatformService(db)
    baseline = await service.create_baseline_version(project_id, screen_key, device_key, language_code, accessibility_key)
    return {"status": "ok", "baseline_id": baseline.id, "active_version": baseline.active_version}

@app.post("/api/baselines/rollback")
def rollback_baseline(req: RollbackRequest, db: Session = Depends(get_db)):
    service = PlatformService(db)
    try:
        baseline = service.rollback_baseline(req)
        return {"status": "ok", "baseline_id": baseline.id, "active_version": baseline.active_version}
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))

# 8. Test Runs
@app.get("/api/test-runs", response_model=List[TestRunResponse])
def get_test_runs(db: Session = Depends(get_db)):
    return db.query(TestRun).order_by(TestRun.id.desc()).all()

@app.post("/api/test-runs", response_model=TestRunResponse)
async def trigger_test_run(req: TestRunCreate, db: Session = Depends(get_db)):
    service = PlatformService(db)
    test_run = await service.run_test_suite(req)
    return test_run

# 9. Defects & Human Review
@app.get("/api/defects", response_model=List[DefectResponse])
def get_defects(
    severity: Optional[str] = None,
    review_status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Defect)
    if severity:
        query = query.filter(Defect.severity == severity)
    if review_status:
        query = query.filter(Defect.review_status == review_status)
    return query.order_by(Defect.id.desc()).all()

@app.get("/api/defects/{defect_id}", response_model=DefectResponse)
def get_defect_details(defect_id: int, db: Session = Depends(get_db)):
    defect = db.query(Defect).filter(Defect.id == defect_id).first()
    if not defect:
        raise HTTPException(status_code=404, detail="Defect not found")
    return defect

@app.post("/api/defects/{defect_id}/review", response_model=DefectResponse)
def review_defect(defect_id: int, req: DefectReviewRequest, db: Session = Depends(get_db)):
    service = PlatformService(db)
    try:
        defect = service.review_defect(defect_id, req)
        return defect
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))

# 10. Evidence
@app.get("/api/evidence/{defect_id}", response_model=EvidenceResponse)
def get_evidence(defect_id: int, db: Session = Depends(get_db)):
    ev = db.query(Evidence).filter(Evidence.defect_id == defect_id).first()
    if not ev:
        raise HTTPException(status_code=404, detail="Evidence package not found")
    return ev

# 11. Audit Logs
@app.get("/api/audit-logs", response_model=List[AuditLogResponse])
def get_audit_logs(db: Session = Depends(get_db)):
    return db.query(AuditLog).order_by(AuditLog.id.desc()).all()

# 12. Experimental Benchmarking API
@app.post("/api/experiments/run")
async def run_experiment_api(db: Session = Depends(get_db)):
    res = await run_comparative_experiment()
    return res

# 13. Quantitative Pipeline Execution Logs API
@app.get("/api/pipeline-logs")
def get_pipeline_execution_logs():
    return [
        {
            "id": "LOG-TRACE-001",
            "scenario": "TC-DEFECT-004",
            "screen": "cart",
            "device": "desktop_1920x1080",
            "language": "en",
            "accessibility": "default",
            "defect_type": "MISSING_ELEMENT",
            "logs": [
                "2026-09-28 14:20:01.002 [INFO] Launching Headless Chromium Browser (1920x1080, DPR: 1.0)",
                "2026-09-28 14:20:01.185 [INFO] Navigating to http://127.0.0.1:8000/pos-app/#cart?lang=en&a11y=default",
                "2026-09-28 14:20:01.450 [INFO] Injection status: DEFECT_INJECTED = 'missing_element'",
                "2026-09-28 14:20:01.482 [INFO] Capturing DOM Element Tree (18 interactive nodes)...",
                "2026-09-28 14:20:01.575 [DEBUG] OpenCV SSIM Score = 0.9842 | Changed Pixels = 412 / 2073600 (0.0198%)",
                "2026-09-28 14:20:01.625 [WARN] Approach A (Pixel) classification: PASS [FALSE NEGATIVE]",
                "2026-09-28 14:20:01.645 [ERROR] [StructuralDetector] DEFECT DETECTED: [MISSING_ELEMENT] 'span#order-total-val' missing. Severity: CRITICAL",
                "2026-09-28 14:20:01.670 [INFO] Approach B (Hybrid) Final Classification: TRUE_DEFECT | Aggregate Score: 0.8836"
            ]
        },
        {
            "id": "LOG-TRACE-002",
            "scenario": "TC-DEFECT-001",
            "screen": "checkout",
            "device": "tablet_1024x768",
            "language": "de",
            "accessibility": "large_text",
            "defect_type": "OVERLAP",
            "logs": [
                "2026-09-28 14:21:05.110 [INFO] Launching Headless Chromium Browser (1024x768, DPR: 2.0)",
                "2026-09-28 14:21:05.290 [INFO] Navigating to http://127.0.0.1:8000/pos-app/#checkout?lang=de&a11y=large_text",
                "2026-09-28 14:21:05.520 [INFO] Injection status: DEFECT_INJECTED = 'overlap'",
                "2026-09-28 14:21:05.680 [DEBUG] OpenCV SSIM Score = 0.7412 | Changed Pixels = 68410 / 786432 (8.6987%)",
                "2026-09-28 14:21:05.710 [ERROR] [StructuralDetector] Collision: button#btn-proceed-pay overlaps div#summary-total-card (Ratio: 1.000 > 0.20)",
                "2026-09-28 14:21:05.760 [INFO] Approach B (Hybrid) Final Classification: TRUE_DEFECT | Severity: CRITICAL | Score: 0.6853"
            ]
        },
        {
            "id": "LOG-TRACE-003",
            "scenario": "TC-DEFECT-007",
            "screen": "cart",
            "device": "mobile_390x844",
            "language": "ar",
            "accessibility": "default",
            "defect_type": "RTL_LAYOUT_ERROR",
            "logs": [
                "2026-09-28 14:22:12.005 [INFO] Launching Headless Chromium Browser (390x844, DPR: 3.0)",
                "2026-09-28 14:22:12.210 [INFO] Navigating to http://127.0.0.1:8000/pos-app/#cart?lang=ar&a11y=default",
                "2026-09-28 14:22:12.635 [ERROR] [LocalizationDetector] RTL Directional Alignment Failure: th#tbl-hdr-rtl_layout_error text-align=left in Arabic",
                "2026-09-28 14:22:12.660 [INFO] Approach B (Hybrid) Final Classification: TRUE_DEFECT | Severity: HIGH | Score: 0.9155"
            ]
        },
        {
            "id": "LOG-TRACE-004",
            "scenario": "TC-GOOD-005",
            "screen": "payment",
            "device": "pos_kiosk_1280x720",
            "language": "hi",
            "accessibility": "high_contrast",
            "defect_type": "NONE",
            "logs": [
                "2026-09-28 14:23:40.010 [INFO] Launching Headless Chromium Browser (1280x720, DPR: 1.0)",
                "2026-09-28 14:23:40.190 [INFO] Navigating to http://127.0.0.1:8000/pos-app/#payment?lang=hi&a11y=high_contrast",
                "2026-09-28 14:23:40.525 [DEBUG] OpenCV SSIM Score = 1.0000 | 0.0% diff | 0 collisions | 0 A11y violations",
                "2026-09-28 14:23:40.585 [INFO] Approach B (Hybrid) Final Classification: PASS | Score: 1.0000"
            ]
        }
    ]

# 14. Detection Thresholds & Defect Taxonomy API
@app.get("/api/documentation/thresholds")
def get_detection_thresholds_doc():
    return {
        "defect_taxonomy": [
            {"label": "OVERLAP", "severity": "CRITICAL", "engine": "Structural", "formula": "IoU > 0.20", "description": "Bounding box collision between interactive nodes"},
            {"label": "TEXT_CUTOFF", "severity": "HIGH", "engine": "Localization", "formula": "Bounds Overflow", "description": "Text truncated without ellipsis by container bounds"},
            {"label": "LAYOUT_SHIFT", "severity": "HIGH", "engine": "Structural", "formula": "dx > 35px OR dy > 35px", "description": "Spatial node center displacement from reference"},
            {"label": "MISSING_ELEMENT", "severity": "CRITICAL", "engine": "Structural", "formula": "Node in Ref AND Node not in Act", "description": "Required reference node omitted from rendered DOM"},
            {"label": "WRONG_POSITION", "severity": "HIGH", "engine": "Structural", "formula": "Position Shift > 50px", "description": "Absolute positioning layout violation"},
            {"label": "LOCALIZATION_OVERFLOW", "severity": "HIGH", "engine": "Localization", "formula": "x + w > W_viewport + 10px", "description": "Translated string exceeds maximum screen bounds"},
            {"label": "RTL_LAYOUT_ERROR", "severity": "HIGH", "engine": "Localization", "formula": "Lang == 'ar' AND Align == 'left'", "description": "Failure to mirror text/flex direction in Arabic locale"},
            {"label": "ACCESSIBLE_NAME_MISSING", "severity": "HIGH", "engine": "Accessibility", "formula": "Tag in [btn, input, a] AND len(aria-label + text) == 0", "description": "Interactive control missing accessible screen reader name"},
            {"label": "ROLE_MISMATCH", "severity": "HIGH", "engine": "Accessibility", "formula": "Tag == 'button' AND Role not in [button, link]", "description": "Control tag exhibits non-standard ARIA role"},
            {"label": "CONTROL_TOO_SMALL", "severity": "MEDIUM", "engine": "Accessibility", "formula": "Width < 44px OR Height < 44px", "description": "Violation of WCAG 2.1 AA touch target 44x44px minimum"},
            {"label": "CONTRAST_ERROR", "severity": "HIGH", "engine": "Accessibility", "formula": "Contrast Ratio < 4.5:1", "description": "WCAG text-to-background color contrast violation"}
        ],
        "device_matrix": [
            {"key": "desktop_1920x1080", "name": "Desktop 1080p", "width": 1920, "height": 1080, "dpr": 1.0, "ratio": "16:9"},
            {"key": "tablet_1024x768", "name": "Tablet Landscape", "width": 1024, "height": 768, "dpr": 2.0, "ratio": "4:3"},
            {"key": "mobile_390x844", "name": "Mobile Portrait", "width": 390, "height": 844, "dpr": 3.0, "ratio": "19.5:9"},
            {"key": "pos_kiosk_1280x720", "name": "POS Kiosk Terminal", "width": 1280, "height": 720, "dpr": 1.0, "ratio": "16:9"}
        ]
    }

# Mount Frontend Dashboard at Root (Must be mounted last to allow API routes precedence)
frontend_dir = os.path.abspath("./frontend")
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")

