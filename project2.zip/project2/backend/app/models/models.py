import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="REVIEWER") # ADMIN, QA, REVIEWER, VIEWER
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    version = Column(String, default="1.0.0")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    screens = relationship("Screen", back_populates="project", cascade="all, delete-orphan")
    baselines = relationship("Baseline", back_populates="project", cascade="all, delete-orphan")
    test_runs = relationship("TestRun", back_populates="project", cascade="all, delete-orphan")

class Screen(Base):
    __tablename__ = "screens"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    name = Column(String, nullable=False) # e.g. Checkout
    screen_key = Column(String, index=True, nullable=False) # e.g. checkout
    route_path = Column(String, nullable=False) # e.g. ?screen=checkout
    description = Column(Text, nullable=True)

    project = relationship("Project", back_populates="screens")

class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False) # e.g. Tablet
    device_key = Column(String, unique=True, index=True, nullable=False) # e.g. tablet_1024x768
    width = Column(Integer, nullable=False)
    height = Column(Integer, nullable=False)
    dpr = Column(Float, default=1.0)
    browser = Column(String, default="chromium")

class Language(Base):
    __tablename__ = "languages"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String, unique=True, index=True, nullable=False) # en, de, ar, ta, hi
    name = Column(String, nullable=False)
    is_rtl = Column(Boolean, default=False)

class AccessibilityProfile(Base):
    __tablename__ = "accessibility_profiles"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String, unique=True, index=True, nullable=False) # default, large_text, high_contrast, keyboard_nav, reduced_motion
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)

class Baseline(Base):
    __tablename__ = "baselines"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    screen_key = Column(String, nullable=False)
    device_key = Column(String, nullable=False)
    language_code = Column(String, nullable=False)
    accessibility_key = Column(String, nullable=False)
    active_version = Column(String, default="baseline-v1")
    status = Column(String, default="ACTIVE") # PROPOSED, APPROVED, ACTIVE, ARCHIVED
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    project = relationship("Project", back_populates="baselines")
    versions = relationship("BaselineVersion", back_populates="baseline", cascade="all, delete-orphan")

class BaselineVersion(Base):
    __tablename__ = "baseline_versions"

    id = Column(Integer, primary_key=True, index=True)
    baseline_id = Column(Integer, ForeignKey("baselines.id"), nullable=False)
    version_tag = Column(String, nullable=False) # baseline-v1, baseline-v2
    screenshot_path = Column(String, nullable=False)
    accessibility_tree_path = Column(String, nullable=False)
    dom_metadata_path = Column(String, nullable=False)
    created_by = Column(String, default="system")
    approval_status = Column(String, default="APPROVED")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    baseline = relationship("Baseline", back_populates="versions")

class TestRun(Base):
    __tablename__ = "test_runs"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    run_type = Column(String, default="REGRESSION") # REGRESSION, GROUND_TRUTH, AD_HOC
    detector_mode = Column(String, default="HYBRID") # PIXEL, HYBRID
    status = Column(String, default="PENDING") # PENDING, RUNNING, COMPLETED, EXECUTION_FAILURE
    error_message = Column(Text, nullable=True)
    total_scenarios = Column(Integer, default=0)
    passed_count = Column(Integer, default=0)
    warning_count = Column(Integer, default=0)
    defect_count = Column(Integer, default=0)
    execution_time_ms = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    project = relationship("Project", back_populates="test_runs")
    actual_snapshots = relationship("ActualSnapshot", back_populates="test_run", cascade="all, delete-orphan")

class ActualSnapshot(Base):
    __tablename__ = "actual_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    test_run_id = Column(Integer, ForeignKey("test_runs.id"), nullable=False)
    screen_key = Column(String, nullable=False)
    device_key = Column(String, nullable=False)
    language_code = Column(String, nullable=False)
    accessibility_key = Column(String, nullable=False)
    screenshot_path = Column(String, nullable=True)
    accessibility_tree_path = Column(String, nullable=True)
    dom_metadata_path = Column(String, nullable=True)
    status = Column(String, default="SUCCESS") # SUCCESS, EXECUTION_FAILURE
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    test_run = relationship("TestRun", back_populates="actual_snapshots")
    defects = relationship("Defect", back_populates="actual_snapshot", cascade="all, delete-orphan")

class Defect(Base):
    __tablename__ = "defects"

    id = Column(Integer, primary_key=True, index=True)
    defect_code = Column(String, unique=True, index=True, nullable=False) # e.g. DEF-1001
    actual_snapshot_id = Column(Integer, ForeignKey("actual_snapshots.id"), nullable=False)
    baseline_version_tag = Column(String, nullable=False)
    detector_mode = Column(String, nullable=False) # PIXEL vs HYBRID
    defect_type = Column(String, nullable=False) # LAYOUT_SHIFT, OVERLAP, TEXT_CUTOFF, ACCESSIBLE_NAME_MISSING, etc.
    severity = Column(String, nullable=False) # CRITICAL, HIGH, MEDIUM, LOW
    classification = Column(String, default="DEFECT_CANDIDATE") # TRUE_DEFECT, ACCEPTABLE_VARIATION, DEFECT_CANDIDATE
    review_status = Column(String, default="PENDING") # PENDING, APPROVED, REJECTED, EXPECTED
    
    # Scores
    overall_regression_score = Column(Float, default=0.0)
    visual_score = Column(Float, default=0.0)
    ssim_score = Column(Float, default=1.0)
    geometry_score = Column(Float, default=0.0)
    accessibility_score = Column(Float, default=0.0)
    localization_score = Column(Float, default=0.0)
    
    explanation = Column(Text, nullable=False)
    reproduction_config = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    actual_snapshot = relationship("ActualSnapshot", back_populates="defects")
    evidence = relationship("Evidence", back_populates="defect", uselist=False, cascade="all, delete-orphan")
    reviews = relationship("Review", back_populates="defect", cascade="all, delete-orphan")

class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    defect_id = Column(Integer, ForeignKey("defects.id"), nullable=False)
    reference_screenshot_path = Column(String, nullable=False)
    actual_screenshot_path = Column(String, nullable=False)
    diff_image_path = Column(String, nullable=False)
    highlighted_region_path = Column(String, nullable=False)
    geometry_evidence = Column(JSON, nullable=True)
    accessibility_diff = Column(JSON, nullable=True)
    detector_metadata = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    defect = relationship("Defect", back_populates="evidence")

class Review(Base):
    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, index=True)
    defect_id = Column(Integer, ForeignKey("defects.id"), nullable=False)
    reviewer_name = Column(String, nullable=False)
    action = Column(String, nullable=False) # APPROVED, REJECTED, EXPECTED, REOPENED
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    defect = relationship("Defect", back_populates="reviews")

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user = Column(String, nullable=False)
    action = Column(String, nullable=False) # PROJECT_CREATED, BASELINE_APPROVED, ROLLBACK_EXECUTED, etc.
    entity_type = Column(String, nullable=False)
    entity_id = Column(String, nullable=False)
    previous_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    reason = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class Experiment(Base):
    __tablename__ = "experiments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    dataset_version = Column(String, default="v1.0")
    results_summary = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class GroundTruthCase(Base):
    __tablename__ = "ground_truth_cases"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(String, unique=True, index=True, nullable=False) # e.g. TC-001
    screen_key = Column(String, nullable=False)
    device_key = Column(String, nullable=False)
    language_code = Column(String, nullable=False)
    accessibility_key = Column(String, nullable=False)
    defect_type = Column(String, nullable=False) # NONE if known good
    severity = Column(String, nullable=False) # NONE, LOW, MEDIUM, HIGH, CRITICAL
    ground_truth_label = Column(String, nullable=False) # KNOWN_GOOD, KNOWN_DEFECTIVE
    expected_behavior = Column(Text, nullable=False)
    defect_injection_flag = Column(String, nullable=True)

class RollbackEvent(Base):
    __tablename__ = "rollback_events"

    id = Column(Integer, primary_key=True, index=True)
    baseline_id = Column(Integer, nullable=False)
    previous_version_tag = Column(String, nullable=False)
    restored_version_tag = Column(String, nullable=False)
    initiated_by = Column(String, nullable=False)
    reason = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
