import os
from pydantic import BaseModel

class Settings(BaseModel):
    PROJECT_NAME: str = os.getenv("PROJECT_NAME", "CrossSight POS Platform")
    VERSION: str = os.getenv("VERSION", "1.0.0")
    API_PREFIX: str = "/api"
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./crosssight.db")
    
    # Artifact Storage
    ARTIFACT_DIR: str = os.getenv("ARTIFACT_DIR", "./artifacts")
    BASELINE_DIR: str = os.getenv("BASELINE_DIR", "./artifacts/baselines")
    SCREENSHOT_DIR: str = os.getenv("SCREENSHOT_DIR", "./artifacts/screenshots")
    ACCESSIBILITY_DIR: str = os.getenv("ACCESSIBILITY_DIR", "./artifacts/accessibility")
    EVIDENCE_DIR: str = os.getenv("EVIDENCE_DIR", "./artifacts/evidence")
    
    # POS Server URL for Playwright
    POS_APP_URL: str = os.getenv("POS_APP_URL", "http://127.0.0.1:8000/pos-app/index.html")
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "super-secret-key-crosssight-pos")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

settings = Settings()
