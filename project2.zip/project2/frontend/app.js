/* CrossSight POS Dashboard SPA Frontend Logic */

(function () {
  'use strict';

  const API_BASE = '/api';
  let currentView = 'dashboard';
  let activeDefect = null;

  // DOM Elements
  const navLinks = document.querySelectorAll('.nav-link');
  const views = document.querySelectorAll('.app-view');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');
  const badgeDefectCount = document.getElementById('badge-defect-count');

  // View Titles Dictionary
  const VIEW_TITLES = {
    dashboard: { title: "Overview Dashboard", sub: "Real-time cross-device visual & accessibility regression intelligence" },
    "test-runs": { title: "Execute Regression Test Suite", sub: "Data-driven Playwright automation runner across viewports, languages and accessibility profiles" },
    "defect-queue": { title: "Regression Defect Queue", sub: "Prioritized defect candidate triage with multi-dimensional filtering" },
    evidence: { title: "Evidence Package & Explainability Viewer", sub: "Deep computer-vision heatmap overlays, geometry diffs, and accessibility tree audit" },
    rollback: { title: "Baseline Versioning & Rollback Control", sub: "Audit trail governance and baseline version restoration" },
    "audit-logs": { title: "Platform Audit Log Trail", sub: "Immutable tracking of high-impact reviewer actions and baseline updates" },
    experiments: { title: "Approach Benchmarking & Evaluation", sub: "Head-to-head empirical comparison of Approach A (Pixel) vs Approach B (Hybrid)" },
    "pipeline-logs": { title: "Pipeline Execution Log Traces", sub: "Step-by-step execution traces across reference devices and localized screen snapshots" },
    "architecture-doc": { title: "Engine Architecture & API Schemas", sub: "Multi-layer detection flow, Mermaid architecture diagrams, and OpenAPI schemas" },
    "thresholds-doc": { title: "Explicit Defect Labels & Thresholds", sub: "Mathematical detection thresholds, WCAG rules, and baseline metrics" },
    devices: { title: "Hardware & Device Configurations", sub: "Supported POS terminal viewports and viewport specs" },
    languages: { title: "Supported Languages & Localization", sub: "Multi-language translations, German long-text expansion, and Arabic RTL" },
    accessibility: { title: "Accessibility Profiles", sub: "WCAG 2.1 compliance profiles and assistive navigation options" }
  };

  // Initialize SPA
  function init() {
    attachEventListeners();
    switchView('dashboard');
    refreshData();
  }

  // View Navigation Switcher
  function switchView(viewName) {
    currentView = viewName;

    navLinks.forEach(link => {
      if (link.dataset.view === viewName) link.classList.add('active');
      else link.classList.remove('active');
    });

    views.forEach(v => {
      if (v.id === `view-${viewName}`) v.classList.add('active');
      else v.classList.remove('active');
    });

    const info = VIEW_TITLES[viewName] || { title: "CrossSight POS", sub: "Regression Platform" };
    if (pageTitle) pageTitle.textContent = info.title;
    if (pageSubtitle) pageSubtitle.textContent = info.sub;

    // Load specific view data
    if (viewName === 'dashboard') loadDashboardData();
    if (viewName === 'test-runs') loadTestRunsData();
    if (viewName === 'defect-queue') loadDefectsData();
    if (viewName === 'rollback') loadBaselinesData();
    if (viewName === 'audit-logs') loadAuditLogsData();
    if (viewName === 'devices') loadMasterData();
    if (viewName === 'pipeline-logs') loadPipelineLogsData();
    if (viewName === 'thresholds-doc') loadThresholdsDocData();
  }

  // Refresh All Dashboard Summaries
  async function refreshData() {
    try {
      const res = await fetch(`${API_BASE}/defects`);
      if (res.ok) {
        const defects = await res.json();
        const pending = defects.filter(d => d.review_status === 'PENDING').length;
        if (badgeDefectCount) badgeDefectCount.textContent = pending;
      }
    } catch (e) {
      console.warn("API offline or starting up...", e);
    }
  }

  // 1. Dashboard View Loader
  async function loadDashboardData() {
    try {
      const [runsRes, defectsRes] = await Promise.all([
        fetch(`${API_BASE}/test-runs`),
        fetch(`${API_BASE}/defects`)
      ]);

      if (runsRes.ok && defectsRes.ok) {
        const runs = await runsRes.json();
        const defects = await defectsRes.json();

        let totalScenarios = 0;
        let totalPassed = 0;
        runs.forEach(r => {
          totalScenarios += r.total_scenarios;
          totalPassed += r.passed_count;
        });

        const passRate = totalScenarios > 0 ? Math.round((totalPassed / totalScenarios) * 100) : 100;
        const criticalCount = defects.filter(d => d.severity === 'CRITICAL' || d.severity === 'HIGH').length;

        document.getElementById('m-total-tests').textContent = totalScenarios;
        document.getElementById('m-pass-rate').textContent = `${passRate}%`;
        document.getElementById('m-critical-defects').textContent = criticalCount;

        // Render Recent Defects
        const tbody = document.getElementById('tbl-recent-defects');
        if (tbody) {
          tbody.innerHTML = defects.slice(0, 5).map(d => `
            <tr>
              <td><strong>${d.defect_code}</strong></td>
              <td><span class="badge badge-${d.severity === 'CRITICAL' ? 'danger' : 'warning'}">${d.severity}</span></td>
              <td>${d.defect_type}</td>
              <td>${d.reproduction_config?.screen || 'Checkout'} (${d.reproduction_config?.language || 'EN'})</td>
              <td><strong>${d.overall_regression_score}</strong></td>
              <td><span class="badge badge-info">${d.review_status}</span></td>
              <td><button class="btn btn-sm btn-primary btn-inspect-ev" data-id="${d.id}">Inspect Evidence</button></td>
            </tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
    }
  }

  // 2. Test Runs View Loader
  async function loadTestRunsData() {
    try {
      const res = await fetch(`${API_BASE}/test-runs`);
      if (res.ok) {
        const runs = await res.json();
        const tbody = document.getElementById('tbl-test-runs');
        if (tbody) {
          tbody.innerHTML = runs.map(r => `
            <tr>
              <td>#${r.id}</td>
              <td><span class="badge badge-info">${r.detector_mode}</span></td>
              <td><span class="badge badge-${r.status === 'COMPLETED' ? 'success' : 'danger'}">${r.status}</span></td>
              <td>${r.total_scenarios}</td>
              <td>${r.passed_count}</td>
              <td><strong class="text-danger">${r.defect_count}</strong></td>
              <td>${Math.round(r.execution_time_ms)} ms</td>
              <td>${new Date(r.created_at).toLocaleString()}</td>
            </tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load test runs:", err);
    }
  }

  // 3. Defect Queue View Loader
  async function loadDefectsData() {
    const sev = document.getElementById('filter-severity')?.value || '';
    const st = document.getElementById('filter-status')?.value || '';
    let url = `${API_BASE}/defects?`;
    if (sev) url += `severity=${sev}&`;
    if (st) url += `review_status=${st}`;

    try {
      const res = await fetch(url);
      if (res.ok) {
        const defects = await res.json();
        const tbody = document.getElementById('tbl-defect-queue');
        if (tbody) {
          tbody.innerHTML = defects.map(d => `
            <tr>
              <td><strong>${d.defect_code}</strong></td>
              <td><span class="badge badge-${d.severity === 'CRITICAL' ? 'danger' : 'warning'}">${d.severity}</span></td>
              <td>${d.defect_type}</td>
              <td><span class="badge badge-info">${d.detector_mode}</span></td>
              <td><strong>${d.overall_regression_score}</strong></td>
              <td><span class="badge badge-${d.review_status === 'APPROVED' ? 'success' : d.review_status === 'REJECTED' ? 'secondary' : 'warning'}">${d.review_status}</span></td>
              <td><button class="btn btn-sm btn-primary btn-inspect-ev" data-id="${d.id}">View Evidence</button></td>
            </tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load defects queue:", err);
    }
  }

  // 4. Evidence Package Viewer Loader
  async function loadEvidenceViewer(defectId) {
    try {
      const [defectRes, evRes] = await Promise.all([
        fetch(`${API_BASE}/defects/${defectId}`),
        fetch(`${API_BASE}/evidence/${defectId}`)
      ]);

      if (defectRes.ok && evRes.ok) {
        const defect = await defectRes.json();
        const ev = await evRes.json();
        activeDefect = defect;

        document.getElementById('ev-code').textContent = defect.defect_code;
        document.getElementById('ev-severity').textContent = defect.severity;
        document.getElementById('ev-type').textContent = defect.defect_type;
        document.getElementById('ev-explanation').textContent = defect.explanation;

        // Image Sources
        document.getElementById('img-ref').src = `/${ev.reference_screenshot_path.replace('./', '')}`;
        document.getElementById('img-act').src = `/${ev.actual_screenshot_path.replace('./', '')}`;
        document.getElementById('img-diff').src = `/${ev.diff_image_path.replace('./', '')}`;
        document.getElementById('img-highlight').src = `/${ev.highlighted_region_path.replace('./', '')}`;

        // Score Breakdown Box
        const scoreBox = document.getElementById('score-breakdown-box');
        if (scoreBox) {
          scoreBox.innerHTML = `
            <div class="metric-row"><span>Overall Regression Score:</span><strong>${defect.overall_regression_score}</strong></div>
            <div class="metric-row"><span>Visual (SSIM) Score:</span><strong>${defect.visual_score}</strong></div>
            <div class="metric-row"><span>Geometry / Bounding Box Score:</span><strong>${defect.geometry_score}</strong></div>
            <div class="metric-row"><span>Accessibility Tree Score:</span><strong>${defect.accessibility_score}</strong></div>
            <div class="metric-row"><span>Localization / RTL Score:</span><strong>${defect.localization_score}</strong></div>
          `;
        }

        // Reproduction Config JSON Box
        const reproBox = document.getElementById('repro-config-box');
        if (reproBox) {
          reproBox.textContent = JSON.stringify(defect.reproduction_config || {}, null, 2);
        }

        switchView('evidence');
      }
    } catch (err) {
      console.error("Failed to load evidence package:", err);
    }
  }

  // 5. Baselines View Loader
  async function loadBaselinesData() {
    try {
      const res = await fetch(`${API_BASE}/baselines`);
      if (res.ok) {
        const baselines = await res.json();
        const tbody = document.getElementById('tbl-baselines');
        if (tbody) {
          tbody.innerHTML = baselines.map(b => `
            <tr>
              <td>#${b.id}</td>
              <td><strong>${b.screen_key}</strong></td>
              <td>${b.device_key}</td>
              <td>${b.language_code.toUpperCase()}</td>
              <td><span class="badge badge-info">${b.active_version}</span></td>
              <td><span class="badge badge-success">${b.status}</span></td>
              <td><button class="btn btn-sm btn-outline btn-select-rb" data-id="${b.id}" data-ver="${b.active_version}">Select for Rollback</button></td>
            </tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load baselines:", err);
    }
  }

  // 6. Audit Logs View Loader
  async function loadAuditLogsData() {
    try {
      const res = await fetch(`${API_BASE}/audit-logs`);
      if (res.ok) {
        const logs = await res.json();
        const tbody = document.getElementById('tbl-audit-logs');
        if (tbody) {
          tbody.innerHTML = logs.map(l => `
            <tr>
              <td>#${l.id}</td>
              <td>${new Date(l.timestamp).toLocaleString()}</td>
              <td><strong>${l.user}</strong></td>
              <td><span class="badge badge-info">${l.action}</span></td>
              <td>${l.entity_type} #${l.entity_id}</td>
              <td>${l.previous_value || 'N/A'}</td>
              <td><strong class="text-success">${l.new_value || 'N/A'}</strong></td>
              <td>${l.reason || '-'}</td>
            </tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load audit logs:", err);
    }
  }

  // 7. Master Data Loader (Devices, Languages, A11y)
  async function loadMasterData() {
    try {
      const [devRes, langRes, a11yRes] = await Promise.all([
        fetch(`${API_BASE}/devices`),
        fetch(`${API_BASE}/languages`),
        fetch(`${API_BASE}/accessibility-profiles`)
      ]);

      if (devRes.ok) {
        const devices = await devRes.json();
        const tbody = document.getElementById('tbl-devices');
        if (tbody) {
          tbody.innerHTML = devices.map(d => `
            <tr><td><strong>${d.name}</strong></td><td>${d.device_key}</td><td>${d.width} x ${d.height}</td><td>${d.dpr}x</td></tr>
          `).join('');
        }
      }

      if (langRes.ok) {
        const langs = await langRes.json();
        const tbody = document.getElementById('tbl-languages');
        if (tbody) {
          tbody.innerHTML = langs.map(l => `
            <tr><td><strong>${l.code.toUpperCase()}</strong></td><td>${l.name}</td><td>${l.is_rtl ? 'Right-to-Left (RTL)' : 'Left-to-Right (LTR)'}</td></tr>
          `).join('');
        }
      }

      if (a11yRes.ok) {
        const a11ys = await a11yRes.json();
        const tbody = document.getElementById('tbl-accessibility');
        if (tbody) {
          tbody.innerHTML = a11ys.map(a => `
            <tr><td><strong>${a.key}</strong></td><td>${a.name}</td><td>${a.description}</td></tr>
          `).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load master data:", err);
    }
  }

  // Event Listeners Attachment
  function attachEventListeners() {
    navLinks.forEach(link => {
      link.addEventListener('click', () => switchView(link.dataset.view));
    });

    const btnQuickRun = document.getElementById('btn-trigger-quick-run');
    if (btnQuickRun) {
      btnQuickRun.addEventListener('click', async () => {
        btnQuickRun.disabled = true;
        btnQuickRun.textContent = "⏳ Running Test Suite...";
        try {
          const res = await fetch(`${API_BASE}/test-runs`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_id: 1, detector_mode: 'HYBRID' })
          });
          if (res.ok) {
            await res.json();
            switchView('defect-queue');
            refreshData();
          }
        } catch (e) {
          alert("Error executing test run: " + e);
        } finally {
          btnQuickRun.disabled = false;
          btnQuickRun.textContent = "⚡ Execute Hybrid Regression Suite";
        }
      });
    }

    const btnStartRun = document.getElementById('btn-start-run');
    if (btnStartRun) {
      btnStartRun.addEventListener('click', async () => {
        btnStartRun.disabled = true;
        btnStartRun.textContent = "⏳ Executing Suite...";
        const payload = {
          project_id: 1,
          screen_key: document.getElementById('run-screen').value || null,
          device_key: document.getElementById('run-device').value || null,
          language_code: document.getElementById('run-lang').value || null,
          detector_mode: document.getElementById('run-mode').value
        };

        try {
          const res = await fetch(`${API_BASE}/test-runs`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          if (res.ok) {
            switchView('test-runs');
            refreshData();
          }
        } catch (e) {
          alert("Test execution error: " + e);
        } finally {
          btnStartRun.disabled = false;
          btnStartRun.textContent = "🚀 Launch Regression Test Run";
        }
      });
    }

    // Inspect Evidence Button Delegated Click
    document.addEventListener('click', e => {
      if (e.target.classList.contains('btn-inspect-ev')) {
        const defectId = e.target.dataset.id;
        loadEvidenceViewer(defectId);
      }
      if (e.target.classList.contains('btn-select-rb')) {
        const bId = e.target.dataset.id;
        const bVer = e.target.dataset.ver;
        document.getElementById('rb-baseline-id').value = bId;
        document.getElementById('rb-version-tag').value = bVer;
      }
    });

    const btnBackDefects = document.getElementById('btn-back-defects');
    if (btnBackDefects) btnBackDefects.addEventListener('click', () => switchView('defect-queue'));

    // Approve / Reject Defect Actions
    const btnApprove = document.getElementById('btn-approve-defect');
    if (btnApprove) {
      btnApprove.addEventListener('click', async () => {
        if (!activeDefect) return;
        const res = await fetch(`${API_BASE}/defects/${activeDefect.id}/review`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reviewer_name: "QA Reviewer", action: "APPROVED", notes: "Approved as true visual regression." })
        });
        if (res.ok) {
          alert(`Defect ${activeDefect.defect_code} APPROVED.`);
          switchView('defect-queue');
          refreshData();
        }
      });
    }

    const btnReject = document.getElementById('btn-reject-defect');
    if (btnReject) {
      btnReject.addEventListener('click', async () => {
        if (!activeDefect) return;
        const res = await fetch(`${API_BASE}/defects/${activeDefect.id}/review`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reviewer_name: "QA Reviewer", action: "REJECTED", notes: "Rejected as acceptable rendering variation." })
        });
        if (res.ok) {
          alert(`Defect ${activeDefect.defect_code} REJECTED.`);
          switchView('defect-queue');
          refreshData();
        }
      });
    }

    // Execute Rollback Form Action
    const btnExecRollback = document.getElementById('btn-exec-rollback');
    if (btnExecRollback) {
      btnExecRollback.addEventListener('click', async () => {
        const baselineId = parseInt(document.getElementById('rb-baseline-id').value);
        const versionTag = document.getElementById('rb-version-tag').value;
        const reason = document.getElementById('rb-reason').value;

        if (!baselineId || !versionTag || !reason) {
          alert("Please fill in all baseline rollback fields.");
          return;
        }

        try {
          const res = await fetch(`${API_BASE}/baselines/rollback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ baseline_id: baselineId, target_version_tag: versionTag, user: "QA Reviewer", reason: reason })
          });
          if (res.ok) {
            alert(`Successfully restored Baseline #${baselineId} to ${versionTag}.`);
            switchView('audit-logs');
          } else {
            const err = await res.json();
            alert("Rollback Error: " + err.detail);
          }
        } catch (e) {
          alert("Rollback request failed: " + e);
        }
      });
    }

    // Run Experiment Benchmark Action
    const btnRunExp = document.getElementById('btn-run-experiment');
    if (btnRunExp) {
      btnRunExp.addEventListener('click', async () => {
        btnRunExp.disabled = true;
        btnRunExp.textContent = "⏳ Running Ground Truth Benchmark...";
        const box = document.getElementById('experiment-output-box');
        if (box) box.innerHTML = "<p>Running comparative evaluation of Approach A vs Approach B across ground truth dataset...</p>";

        try {
          const res = await fetch(`${API_BASE}/experiments/run`, { method: 'POST' });
          if (res.ok) {
            const data = await res.json();
            if (box) {
              box.innerHTML = `
                <pre class="json-code-block">${JSON.stringify(data, null, 2)}</pre>
              `;
            }
          }
        } catch (e) {
          if (box) box.innerHTML = `<p class="text-danger">Experiment execution error: ${e}</p>`;
        } finally {
          btnRunExp.disabled = false;
          btnRunExp.textContent = "🧪 Run Full Experiment Suite";
        }
      });
    }

    const btnApplyFilters = document.getElementById('btn-apply-filters');
    if (btnApplyFilters) btnApplyFilters.addEventListener('click', loadDefectsData);
  }

  // 8. Pipeline Execution Log Loader
  async function loadPipelineLogsData() {
    try {
      const res = await fetch(`${API_BASE}/pipeline-logs`);
      if (res.ok) {
        const logsData = await res.json();
        const container = document.getElementById('container-pipeline-logs');
        if (container) {
          container.innerHTML = logsData.map(item => `
            <div class="card card-section margin-bottom">
              <div class="card-header-flex">
                <h3>Trace ${item.id}: Scenario ${item.scenario} (${item.screen.toUpperCase()})</h3>
                <div>
                  <span class="badge badge-info">${item.device}</span>
                  <span class="badge badge-warning">${item.language.toUpperCase()}</span>
                  <span class="badge badge-${item.defect_type === 'NONE' ? 'success' : 'danger'}">${item.defect_type}</span>
                </div>
              </div>
              <pre class="json-code-block" style="background:#0f172a; border-radius:8px; padding:12px; font-size:12px; color:#e2e8f0; max-height:260px; overflow-y:auto;">${item.logs.join('\n')}</pre>
            </div>
          `).join('');
        }
      }
    } catch (e) {
      console.error("Failed to load pipeline logs:", e);
    }
  }

  // 9. Thresholds & Defect Taxonomy Loader
  async function loadThresholdsDocData() {
    try {
      const res = await fetch(`${API_BASE}/documentation/thresholds`);
      if (res.ok) {
        const data = await res.json();
        const tbody = document.getElementById('tbl-thresholds-doc');
        if (tbody && data.defect_taxonomy) {
          tbody.innerHTML = data.defect_taxonomy.map(t => `
            <tr>
              <td><strong>${t.label}</strong></td>
              <td><span class="badge badge-${t.severity === 'CRITICAL' ? 'danger' : t.severity === 'HIGH' ? 'warning' : 'info'}">${t.severity}</span></td>
              <td><span class="badge badge-info">${t.engine}</span></td>
              <td><code class="text-primary">${t.formula}</code></td>
              <td>${t.description}</td>
            </tr>
          `).join('');
        }
      }
    } catch (e) {
      console.error("Failed to load thresholds doc:", e);
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();

