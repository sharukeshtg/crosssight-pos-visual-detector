import os
import json
from typing import List, Dict, Any

GROUND_TRUTH_DATASET: List[Dict[str, Any]] = [
  # ═══════════════════════════════════════════════════════════════════════
  # KNOWN GOOD SCENARIOS (Controls / Harmless Variations)
  # ═══════════════════════════════════════════════════════════════════════
  {
    "case_id": "TC-GOOD-001",
    "screen_key": "checkout",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "Checkout screen renders correctly on standard 1080p desktop with default English labels."
  },
  {
    "case_id": "TC-GOOD-002",
    "screen_key": "checkout",
    "device_key": "tablet_1024x768",
    "language_code": "de",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "German long text expansion fits cleanly without button clipping or element overlapping."
  },
  {
    "case_id": "TC-GOOD-003",
    "screen_key": "cart",
    "device_key": "tablet_1024x768",
    "language_code": "ar",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "Arabic cart table and summary card flip correctly to Right-to-Left (RTL) orientation."
  },
  {
    "case_id": "TC-GOOD-004",
    "screen_key": "search",
    "device_key": "mobile_390x844",
    "language_code": "en",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "Mobile grid wraps product items into single column under 200% large text profile."
  },
  {
    "case_id": "TC-GOOD-005",
    "screen_key": "payment",
    "device_key": "pos_kiosk_1280x720",
    "language_code": "hi",
    "accessibility_key": "high_contrast",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "POS Kiosk Payment screen displays high contrast borders with Hindi payment labels."
  },
  {
    "case_id": "TC-GOOD-006",
    "screen_key": "receipt",
    "device_key": "desktop_1920x1080",
    "language_code": "ta",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "Tamil receipt screen renders Indic script fonts correctly with proper line-height and glyph shaping."
  },
  {
    "case_id": "TC-GOOD-007",
    "screen_key": "login",
    "device_key": "mobile_390x844",
    "language_code": "en",
    "accessibility_key": "keyboard_nav",
    "ground_truth": "KNOWN_GOOD",
    "defect_type": "NONE",
    "severity": "NONE",
    "defect_injection_flag": None,
    "expected_behavior": "Login form is fully keyboard navigable with visible focus rings and correct tab order."
  },

  # ═══════════════════════════════════════════════════════════════════════
  # KNOWN DEFECTIVE SCENARIOS (Controlled Defect Injections)
  # ═══════════════════════════════════════════════════════════════════════

  # --- Original 11 defect types ---
  {
    "case_id": "TC-DEFECT-001",
    "screen_key": "cart",
    "device_key": "tablet_1024x768",
    "language_code": "de",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "OVERLAP",
    "severity": "CRITICAL",
    "defect_injection_flag": "overlap",
    "expected_behavior": "Payment button overlaps order subtotal area, obscuring payable amount."
  },
  {
    "case_id": "TC-DEFECT-002",
    "screen_key": "checkout",
    "device_key": "tablet_1024x768",
    "language_code": "de",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "TEXT_CUTOFF",
    "severity": "HIGH",
    "defect_injection_flag": "text_cutoff",
    "expected_behavior": "German long text button label 'Weiter zur Zahlungsabwicklung' gets truncated to 60px."
  },
  {
    "case_id": "TC-DEFECT-003",
    "screen_key": "cart",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "LAYOUT_SHIFT",
    "severity": "HIGH",
    "defect_injection_flag": "layout_shift",
    "expected_behavior": "Cart order summary container shifts 150px downward leaving huge whitespace gap."
  },
  {
    "case_id": "TC-DEFECT-004",
    "screen_key": "cart",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "MISSING_ELEMENT",
    "severity": "CRITICAL",
    "defect_injection_flag": "missing_element",
    "expected_behavior": "Order Total amount span is hidden from DOM summary card."
  },
  {
    "case_id": "TC-DEFECT-005",
    "screen_key": "payment",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "WRONG_POSITION",
    "severity": "HIGH",
    "defect_injection_flag": "wrong_position",
    "expected_behavior": "Complete Transaction button shifted -200px upward into card header."
  },
  {
    "case_id": "TC-DEFECT-006",
    "screen_key": "checkout",
    "device_key": "tablet_1024x768",
    "language_code": "de",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "LOCALIZATION_OVERFLOW",
    "severity": "HIGH",
    "defect_injection_flag": "localization_overflow",
    "expected_behavior": "German long button exceeds 130% viewport width causing horizontal scroll."
  },
  {
    "case_id": "TC-DEFECT-007",
    "screen_key": "cart",
    "device_key": "tablet_1024x768",
    "language_code": "ar",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "RTL_LAYOUT_ERROR",
    "severity": "HIGH",
    "defect_injection_flag": "rtl_layout_error",
    "expected_behavior": "Arabic cart table headers remain left-aligned instead of flipping to right."
  },
  {
    "case_id": "TC-DEFECT-008",
    "screen_key": "payment",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "keyboard_nav",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "ACCESSIBLE_NAME_MISSING",
    "severity": "HIGH",
    "defect_injection_flag": "missing_aria_label",
    "expected_behavior": "Payment submission button has empty aria-label attribute."
  },
  {
    "case_id": "TC-DEFECT-009",
    "screen_key": "cart",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "keyboard_nav",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "ROLE_MISMATCH",
    "severity": "HIGH",
    "defect_injection_flag": "role_mismatch",
    "expected_behavior": "Proceed to Checkout button has role='paragraph' breaking screen reader interaction."
  },
  {
    "case_id": "TC-DEFECT-010",
    "screen_key": "payment",
    "device_key": "mobile_390x844",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "CONTROL_TOO_SMALL",
    "severity": "MEDIUM",
    "defect_injection_flag": "control_too_small",
    "expected_behavior": "Payment button shrunk to 9px height violating 44x44px touch target minimum."
  },
  {
    "case_id": "TC-DEFECT-011",
    "screen_key": "checkout",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "high_contrast",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "CONTRAST_ERROR",
    "severity": "HIGH",
    "defect_injection_flag": "contrast_error",
    "expected_behavior": "Payment button text background changed to low-contrast dark grey on dark grey."
  },

  # --- NEW defect types (expanded taxonomy) ---
  {
    "case_id": "TC-DEFECT-012",
    "screen_key": "checkout",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "high_contrast",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "COLOR_CONTRAST_ERROR",
    "severity": "HIGH",
    "defect_injection_flag": "color_contrast_error",
    "expected_behavior": "Submit button foreground #777 on background #888 produces contrast ratio 1.18:1, failing WCAG AA 4.5:1 minimum."
  },
  {
    "case_id": "TC-DEFECT-013",
    "screen_key": "cart",
    "device_key": "tablet_1024x768",
    "language_code": "en",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "FONT_SIZE_REGRESSION",
    "severity": "HIGH",
    "defect_injection_flag": "font_size_regression",
    "expected_behavior": "Product name font regresses from 16px baseline to 9px actual, a 43.75% deviation exceeding 20% threshold."
  },
  {
    "case_id": "TC-DEFECT-014",
    "screen_key": "checkout",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "keyboard_nav",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "FOCUS_ORDER_REGRESSION",
    "severity": "HIGH",
    "defect_injection_flag": "focus_order_regression",
    "expected_behavior": "Address input receives focus before Name input, violating logical top-to-bottom flow."
  },
  {
    "case_id": "TC-DEFECT-015",
    "screen_key": "payment",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "keyboard_nav",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "TAB_ORDER_REGRESSION",
    "severity": "HIGH",
    "defect_injection_flag": "tab_order_regression",
    "expected_behavior": "Credit card number input tabindex changed from 0 to 5, skipping card expiry and CVV fields."
  },
  {
    "case_id": "TC-DEFECT-016",
    "screen_key": "cart",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "ELEMENT_ADDED_UNEXPECTEDLY",
    "severity": "MEDIUM",
    "defect_injection_flag": "element_added_unexpectedly",
    "expected_behavior": "Unexpected promotional banner div injected between cart items and summary, pushing summary below fold."
  },
  {
    "case_id": "TC-DEFECT-017",
    "screen_key": "payment",
    "device_key": "tablet_1024x768",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "Z_INDEX_REGRESSION",
    "severity": "MEDIUM",
    "defect_injection_flag": "z_index_regression",
    "expected_behavior": "Payment modal z-index dropped from 1000 to 1, causing it to render behind overlay backdrop."
  },
  {
    "case_id": "TC-DEFECT-018",
    "screen_key": "checkout",
    "device_key": "mobile_390x844",
    "language_code": "de",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "CLIPPED_ELEMENT",
    "severity": "HIGH",
    "defect_injection_flag": "clipped_element",
    "expected_behavior": "Order summary container has overflow:hidden clipping German translated totals row."
  },
  {
    "case_id": "TC-DEFECT-019",
    "screen_key": "cart",
    "device_key": "mobile_390x844",
    "language_code": "de",
    "accessibility_key": "large_text",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "HORIZONTAL_SCROLL",
    "severity": "HIGH",
    "defect_injection_flag": "horizontal_scroll",
    "expected_behavior": "Cart table extends 180px beyond 390px mobile viewport, introducing unintended horizontal scrollbar."
  },
  {
    "case_id": "TC-DEFECT-020",
    "screen_key": "receipt",
    "device_key": "mobile_390x844",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "VERTICAL_SCROLL",
    "severity": "MEDIUM",
    "defect_injection_flag": "vertical_scroll",
    "expected_behavior": "Receipt page content height balloons from 800px to 2400px due to duplicated line items."
  },
  {
    "case_id": "TC-DEFECT-021",
    "screen_key": "search",
    "device_key": "desktop_1920x1080",
    "language_code": "en",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "IMAGE_ICON_MISSING",
    "severity": "HIGH",
    "defect_injection_flag": "image_icon_missing",
    "expected_behavior": "Product thumbnail images fail to load, collapsing to 0x0px broken image placeholders."
  },
  {
    "case_id": "TC-DEFECT-022",
    "screen_key": "checkout",
    "device_key": "tablet_1024x768",
    "language_code": "hi",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "LANGUAGE_FALLBACK_ERROR",
    "severity": "HIGH",
    "defect_injection_flag": "language_fallback_error",
    "expected_behavior": "Hindi checkout screen displays English 'Proceed to Payment' instead of Hindi translation."
  },
  {
    "case_id": "TC-DEFECT-023",
    "screen_key": "cart",
    "device_key": "tablet_1024x768",
    "language_code": "ar",
    "accessibility_key": "default",
    "ground_truth": "KNOWN_DEFECTIVE",
    "defect_type": "DIRECTION_ATTRIBUTE_ERROR",
    "severity": "CRITICAL",
    "defect_injection_flag": "direction_attribute_error",
    "expected_behavior": "Arabic cart page has dir='ltr' on <html> element, preventing RTL layout engine from activating."
  }
]

def save_ground_truth_dataset(output_dir: str = "./experiments/ground_truth"):
    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, "ground_truth_cases.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(GROUND_TRUTH_DATASET, f, indent=2)

    # Also generate a summary statistics file
    stats = compute_dataset_statistics(GROUND_TRUTH_DATASET)
    stats_path = os.path.join(output_dir, "dataset_statistics.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

    return file_path

def compute_dataset_statistics(dataset: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Computes summary statistics for the ground truth dataset."""
    total = len(dataset)
    good_count = sum(1 for c in dataset if c["ground_truth"] == "KNOWN_GOOD")
    defective_count = sum(1 for c in dataset if c["ground_truth"] == "KNOWN_DEFECTIVE")

    defect_type_dist: Dict[str, int] = {}
    severity_dist: Dict[str, int] = {}
    device_dist: Dict[str, int] = {}
    language_dist: Dict[str, int] = {}
    screen_dist: Dict[str, int] = {}
    a11y_dist: Dict[str, int] = {}

    for c in dataset:
        dt = c["defect_type"]
        defect_type_dist[dt] = defect_type_dist.get(dt, 0) + 1

        sev = c["severity"]
        severity_dist[sev] = severity_dist.get(sev, 0) + 1

        dev = c["device_key"]
        device_dist[dev] = device_dist.get(dev, 0) + 1

        lang = c["language_code"]
        language_dist[lang] = language_dist.get(lang, 0) + 1

        scr = c["screen_key"]
        screen_dist[scr] = screen_dist.get(scr, 0) + 1

        a11y = c["accessibility_key"]
        a11y_dist[a11y] = a11y_dist.get(a11y, 0) + 1

    return {
        "total_cases": total,
        "known_good": good_count,
        "known_defective": defective_count,
        "defect_prevalence_rate": round(defective_count / total * 100, 2) if total > 0 else 0.0,
        "defect_type_distribution": defect_type_dist,
        "severity_distribution": severity_dist,
        "device_distribution": device_dist,
        "language_distribution": language_dist,
        "screen_distribution": screen_dist,
        "accessibility_profile_distribution": a11y_dist,
        "unique_defect_types": len([k for k in defect_type_dist.keys() if k != "NONE"]),
        "unique_devices": len(device_dist),
        "unique_languages": len(language_dist),
        "unique_screens": len(screen_dist)
    }

if __name__ == "__main__":
    path = save_ground_truth_dataset()
    print(f"Ground truth dataset saved to: {path} with {len(GROUND_TRUTH_DATASET)} test cases.")
