import os
import pytest
import numpy as np
import cv2
from engine.visual.pixel_detector import PixelVisualDetector
from engine.structural.structural_detector import StructuralDetector
from engine.accessibility.accessibility_detector import AccessibilityDetector
from engine.localization.localization_detector import LocalizationDetector
from engine.scoring.hybrid_detector import HybridDetector

@pytest.fixture
def temp_images(tmp_path):
    img1 = np.ones((500, 500, 3), dtype=np.uint8) * 255
    img2 = img1.copy()
    cv2.rectangle(img2, (50, 50), (200, 200), (0, 0, 255), -1)

    path1 = str(tmp_path / "img1.png")
    path2 = str(tmp_path / "img2.png")
    cv2.imwrite(path1, img1)
    cv2.imwrite(path2, img2)
    return path1, path2

def test_pixel_visual_detector_identical(temp_images):
    path1, _ = temp_images
    detector = PixelVisualDetector()
    res = detector.compare_screenshots(path1, path1)
    assert res["visual_score"] == 1.0
    assert res["difference_percentage"] == 0.0
    assert res["classification"] == "PASS"

def test_pixel_visual_detector_difference(temp_images):
    path1, path2 = temp_images
    detector = PixelVisualDetector()
    res = detector.compare_screenshots(path1, path2)
    assert res["visual_score"] < 0.95
    assert res["difference_percentage"] > 0.0
    assert res["classification"] == "DEFECT_CANDIDATE"

def test_structural_overlap_detection():
    detector = StructuralDetector()
    ref_nodes = [
        {"id": "btn-pay", "tag": "button", "text": "Pay Now", "visibility": True, "bounds": {"x": 10, "y": 10, "width": 100, "height": 40}},
        {"id": "txt-total", "tag": "span", "text": "$100", "visibility": True, "bounds": {"x": 120, "y": 10, "width": 80, "height": 40}}
    ]
    act_nodes_overlap = [
        {"id": "btn-pay", "tag": "button", "text": "Pay Now", "visibility": True, "bounds": {"x": 10, "y": 10, "width": 150, "height": 40}},
        {"id": "txt-total", "tag": "span", "text": "$100", "visibility": True, "bounds": {"x": 50, "y": 10, "width": 80, "height": 40}} # Overlaps btn-pay!
    ]
    res = detector.compare_geometry(ref_nodes, act_nodes_overlap)
    assert res["geometry_score"] < 1.0
    assert any(d["defect_type"] == "OVERLAP" for d in res["structural_defects"])

def test_accessibility_missing_name_and_role_mismatch():
    detector = AccessibilityDetector()
    nodes = [
        {"id": "btn-1", "tag": "button", "role": "button", "ariaLabel": "", "text": "", "bounds": {"width": 100, "height": 50}, "focusable": True},
        {"id": "btn-2", "tag": "button", "role": "paragraph", "ariaLabel": "Submit", "text": "Submit", "bounds": {"width": 100, "height": 50}, "focusable": True}
    ]
    res = detector.compare_accessibility_tree({}, {}, nodes)
    types = [d["defect_type"] for d in res["accessibility_defects"]]
    assert "ACCESSIBLE_NAME_MISSING" in types
    assert "ROLE_MISMATCH" in types

def test_localization_overflow_german():
    detector = LocalizationDetector()
    nodes = [
        {"id": "btn-checkout", "tag": "button", "text": "Weiter zur Zahlungsabwicklung und Transaktionsbestätigung", "bounds": {"x": 100, "y": 100, "width": 1200, "height": 50}}
    ]
    res = detector.analyze_localization("de", nodes, device_width=1024)
    assert res["localization_score"] < 1.0
    assert res["localization_defects"][0]["defect_type"] == "LOCALIZATION_OVERFLOW"
