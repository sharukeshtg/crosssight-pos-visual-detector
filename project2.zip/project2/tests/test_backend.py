import pytest
from fastapi.testclient import TestClient
from backend.app.main import app, startup_event

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    startup_event()

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_get_projects():
    response = client.get("/api/projects")
    assert response.status_code == 200
    data = response.json()
    assert len(data) > 0

def test_get_screens():
    response = client.get("/api/screens")
    assert response.status_code == 200
    data = response.json()
    assert any(s["screen_key"] == "checkout" for s in data)

def test_get_devices():
    response = client.get("/api/devices")
    assert response.status_code == 200
    data = response.json()
    assert any(d["device_key"] == "tablet_1024x768" for d in data)

def test_get_audit_logs():
    response = client.get("/api/audit-logs")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
