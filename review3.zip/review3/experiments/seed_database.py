import os
import json
import datetime
from sqlalchemy.orm import Session
from backend.app.core.database import SessionLocal, engine, Base
from backend.app.models.models import (
    User, Project, Screen, Device, Language, AccessibilityProfile,
    Baseline, BaselineVersion, TestRun, ActualSnapshot, Defect, Evidence,
    Review, AuditLog, Experiment, GroundTruthCase, RollbackEvent
)
from backend.app.services.services import PlatformService
from experiments.dataset_generator import GROUND_TRUTH_DATASET

def seed_complete_database():
    """
    Populates SQLite database (crosssight.db) with master data, ground truth cases,
    baselines, baseline versions, test runs, defects, evidence, reviews, audit logs,
    and rollback events.
    """
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        service = PlatformService(db)
        
        # 1. Seed Master Data
        service.seed_master_data()
        
        # 2. Seed Ground Truth Cases
        print("Seeding 30 Ground Truth Cases into database...")
        for case in GROUND_TRUTH_DATASET:
            gt_record = db.query(GroundTruthCase).filter(GroundTruthCase.case_id == case["case_id"]).first()
            if not gt_record:
                gt_record = GroundTruthCase(
                    case_id=case["case_id"],
                    screen_key=case["screen_key"],
                    device_key=case["device_key"],
                    language_code=case["language_code"],
                    accessibility_key=case["accessibility_key"],
                    defect_type=case["defect_type"],
                    severity=case["severity"],
                    ground_truth_label=case["ground_truth"],
                    expected_behavior=case["expected_behavior"],
                    defect_injection_flag=case.get("defect_injection_flag")
                )
                db.add(gt_record)
        db.commit()

        # 3. Create Sample Historical Rollback Event & Audit Trail
        proj = db.query(Project).filter(Project.name == "CrossSight POS Default").first()
        baseline = db.query(Baseline).filter(
            Baseline.project_id == proj.id,
            Baseline.screen_key == "checkout",
            Baseline.device_key == "tablet_1024x768"
        ).first()

        if baseline:
            rb_check = db.query(RollbackEvent).filter(RollbackEvent.baseline_id == baseline.id).first()
            if not rb_check:
                rb_event = RollbackEvent(
                    baseline_id=baseline.id,
                    previous_version_tag="baseline-v2",
                    restored_version_tag="baseline-v1",
                    initiated_by="QA Lead Reviewer",
                    reason="Restored baseline-v1 after verifying checkout button alignment in tablet mode.",
                    timestamp=datetime.datetime.utcnow() - datetime.timedelta(hours=2)
                )
                db.add(rb_event)
                service.log_audit(
                    user="QA Lead Reviewer",
                    action="ROLLBACK_EXECUTED",
                    entity_type="Baseline",
                    entity_id=str(baseline.id),
                    prev_val="baseline-v2",
                    new_val="baseline-v1",
                    reason="Restored baseline-v1 after verifying checkout button alignment in tablet mode."
                )
                db.commit()

        # 4. Save Experiment Record if experiment results JSON exists
        res_file = "./experiments/results/experiment_results.json"
        if os.path.exists(res_file):
            with open(res_file, "r", encoding="utf-8") as f:
                exp_data = json.load(f)
            
            exp_rec = db.query(Experiment).filter(Experiment.name == "Head-to-Head Benchmark v1").first()
            if not exp_rec:
                exp_rec = Experiment(
                    name="Head-to-Head Benchmark v1",
                    description="Comparative evaluation of Approach A (Pure Pixel/SSIM) vs Approach B (Hybrid Engine) across 30 ground truth scenarios.",
                    dataset_version="v1.0-30cases",
                    results_summary=exp_data
                )
                db.add(exp_rec)
                db.commit()

        print("Database population completed successfully!")

    finally:
        db.close()

if __name__ == "__main__":
    seed_complete_database()
