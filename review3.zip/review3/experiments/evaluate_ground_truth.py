import os
import json
import asyncio
from experiments.run_experiments import run_comparative_experiment

def generate_ground_truth_results():
    """
    Executes the head-to-head empirical benchmark for Approach A (Pixel) vs Approach B (Hybrid)
    across all 30 Ground-Truth Test Cases in experiments/ground_truth/ground_truth_cases.json.
    Calculates measured TP, TN, FP, FN, Precision, Recall, F1, FPR, FNR, and detection timing.
    """
    print("Executing full 30-scenario Ground Truth Evaluation Suite...")
    return asyncio.run(run_comparative_experiment())

if __name__ == "__main__":
    generate_ground_truth_results()
